"""
Filler Detector for AI Debate Coach
Analyzes speech for fillers and hesitations.
"""
import re
from typing import Dict, Any, List, Tuple

class FillerDetector:
    """Detects filler words and hesitations in speech transcripts."""
    
    def __init__(self):
        """Initialize the filler detector with common filler patterns."""
        # Common filler words and phrases
        self.filler_words = [
            "um", "uh", "er", "ah", "like", "you know", "sort of", "kind of",
            "basically", "literally", "actually", "so", "well", "I mean"
        ]
        
        # Regular expression patterns for detecting fillers
        self.filler_patterns = [
            r'\b' + re.escape(word) + r'\b' 
            for word in self.filler_words
        ]
        
        # Combined pattern for easier matching
        self.combined_pattern = re.compile('|'.join(self.filler_patterns), re.IGNORECASE)
    
    def analyze_transcript(self, transcript: str) -> Dict[str, Any]:
        """
        Analyze a speech transcript for filler words and hesitations.
        
        Args:
            transcript: The text transcript of the speech to analyze
            
        Returns:
            Dict containing analysis results and improvement suggestions
        """
        # Find all filler words
        fillers = self._find_fillers(transcript)
        
        # Analyze pause patterns (represented by "..." or multiple spaces)
        pauses = self._analyze_pauses(transcript)
        
        # Calculate filler density
        word_count = len(transcript.split())
        filler_count = sum(fillers.values())
        filler_density = filler_count / max(1, word_count)
        
        # Calculate overall fluency score
        fluency_score = self._calculate_fluency_score(filler_density, pauses)
        
        return {
            "filler_count": filler_count,
            "word_count": word_count,
            "filler_density": filler_density,
            "filler_breakdown": fillers,
            "pause_analysis": pauses,
            "fluency_score": fluency_score,
            "improvement_suggestions": self._generate_suggestions(fillers, pauses, fluency_score)
        }
    
    def _find_fillers(self, text: str) -> Dict[str, int]:
        """Find and count all filler words in the text."""
        fillers = {}
        for filler in self.filler_words:
            pattern = re.compile(r'\b' + re.escape(filler) + r'\b', re.IGNORECASE)
            matches = pattern.findall(text)
            if matches:
                fillers[filler] = len(matches)
        
        return fillers
    
    def _analyze_pauses(self, text: str) -> Dict[str, Any]:
        """Analyze pause patterns in the text."""
        # Count explicit pause indicators
        ellipsis_count = text.count('...')
        
        # Count multiple spaces (rough indicator of pauses in some transcripts)
        multi_space_count = len(re.findall(r'  +', text))
        
        # Identify sentence fragments (might indicate broken speech)
        fragments = [s.strip() for s in re.split(r'[.!?]', text) if s.strip()]
        short_fragments = [f for f in fragments if len(f.split()) < 3]
        
        return {
            "explicit_pauses": ellipsis_count,
            "implicit_pauses": multi_space_count,
            "fragment_count": len(fragments),
            "short_fragment_count": len(short_fragments),
            "fragment_ratio": len(short_fragments) / max(1, len(fragments))
        }
    
    def _calculate_fluency_score(self, filler_density: float, pause_analysis: Dict[str, Any]) -> float:
        """Calculate an overall fluency score based on fillers and pauses."""
        # Start with a base score
        score = 1.0
        
        # Penalize for filler density
        if filler_density > 0.05:  # More than 5% fillers
            score -= min(0.5, filler_density)
        
        # Penalize for excessive pauses
        pause_ratio = (pause_analysis["explicit_pauses"] + pause_analysis["implicit_pauses"]) / max(1, pause_analysis["fragment_count"])
        if pause_ratio > 0.3:  # More than 30% of sentences have pauses
            score -= min(0.3, pause_ratio - 0.3)
        
        # Penalize for excessive short fragments
        if pause_analysis["fragment_ratio"] > 0.4:  # More than 40% short fragments
            score -= min(0.3, pause_analysis["fragment_ratio"] - 0.4)
            
        # Ensure score is between 0 and 1
        return max(0.0, min(1.0, score))
    
    def _generate_suggestions(
        self, 
        fillers: Dict[str, int], 
        pauses: Dict[str, Any], 
        fluency_score: float
    ) -> List[str]:
        """Generate improvement suggestions based on analysis results."""
        suggestions = []
        
        # Suggestions for fillers
        if fillers:
            common_fillers = sorted(fillers.items(), key=lambda x: x[1], reverse=True)[:3]
            
            if common_fillers:
                filler_list = ", ".join([f"'{f[0]}' ({f[1]} times)" for f in common_fillers])
                suggestions.append(f"Watch out for common filler words: {filler_list}")
        
        # Suggestions for pauses
        if pauses["explicit_pauses"] > 5 or pauses["implicit_pauses"] > 5:
            suggestions.append("Practice speaking with more confident pacing to reduce hesitations")
        
        if pauses["short_fragment_count"] > 3:
            suggestions.append("Work on completing your thoughts before moving to new points")
        
        # General fluency suggestions
        if fluency_score < 0.7:
            suggestions.append("Record yourself speaking and listen for fillers and hesitations")
            suggestions.append("Practice speaking more slowly and deliberately to reduce fillers")
        
        if not suggestions:
            suggestions.append("Your speech fluency is good. Focus on content and delivery.")
            
        return suggestions
        
    def highlight_fillers(self, transcript: str) -> str:
        """
        Create a highlighted version of transcript with fillers marked.
        
        Args:
            transcript: Original speech transcript
            
        Returns:
            Text with fillers wrapped in ** for emphasis
        """
        def replace_match(match):
            return f"**{match.group(0)}**"
            
        return self.combined_pattern.sub(replace_match, transcript)