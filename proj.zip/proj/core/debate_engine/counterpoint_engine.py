"""
Counterpoint Engine for AI Debate Coach
Generates intelligent counterarguments with adversarial reasoning.
"""
import re
import random
from typing import List, Dict, Any, Optional, Tuple

class CounterpointEngine:
    """Generates intelligent counterarguments for debate practice."""
    
    def __init__(self, level: int = 2):
        """
        Initialize the counterpoint engine with complexity level.
        
        Args:
            level: Complexity level (1-3) for counterargument generation
        """
        self.level = min(max(level, 1), 3)
        
        # Counterargument strategies by types
        self.strategy_templates = {
            "evidence_challenge": [
                "The evidence provided for {claim} is inadequate because {reason}.",
                "While {claim} may sound plausible, the evidence cited is problematic: {reason}.",
                "The data supporting {claim} is flawed: {reason}."
            ],
            "causal_fallacy": [
                "The argument incorrectly assumes that {claimed_cause} causes {effect}, when in fact {alternative}.",
                "The causal relationship between {claimed_cause} and {effect} is questionable. A more likely explanation is {alternative}.",
                "Attributing {effect} to {claimed_cause} overlooks that {alternative}."
            ],
            "false_dichotomy": [
                "This argument presents a false choice between {option1} and {option2}. In reality, {alternative}.",
                "Reducing this complex issue to a choice between {option1} and {option2} ignores that {alternative}.",
                "The either/or framing of {option1} versus {option2} is misleading because {alternative}."
            ],
            "slippery_slope": [
                "The claim that {initial_action} will inevitably lead to {extreme_outcome} ignores that {rebuttal}.",
                "There's no evidence that {initial_action} would necessarily result in {extreme_outcome}. In fact, {rebuttal}.",
                "The argument exaggerates the consequences of {initial_action} by claiming it leads to {extreme_outcome}, when in reality {rebuttal}."
            ],
            "moral_equivalence": [
                "Comparing {situation1} to {situation2} creates a false equivalence. The critical difference is {distinction}.",
                "The analogy between {situation1} and {situation2} breaks down because {distinction}.",
                "While superficially similar, {situation1} and {situation2} differ fundamentally: {distinction}."
            ],
            "alternative_perspective": [
                "From a different perspective, {claim} actually leads to {alternative_outcome}.",
                "Looking at this issue through the lens of {perspective}, we see that {alternative_view}.",
                "When we consider {perspective}, the conclusion that {claim} is challenged by {alternative_view}."
            ],
            "unintended_consequences": [
                "While {proposal} might achieve {intended_outcome}, it would also cause {negative_consequence}.",
                "The proposal to {proposal} overlooks the serious side effect of {negative_consequence}.",
                "Although {proposal} seems beneficial, it fails to account for {negative_consequence}."
            ],
            "cost_benefit": [
                "The benefits of {proposal} are outweighed by {costs}.",
                "When we analyze the true costs of {proposal}, which include {costs}, the benefits seem far less compelling.",
                "A cost-benefit analysis of {proposal} must account for {costs}, which renders it impractical."
            ]
        }
        
        # Attack types categorization
        self.attack_types = {
            "evidence_challenge": "evidential",
            "causal_fallacy": "causal",
            "false_dichotomy": "logical",
            "slippery_slope": "consequential",
            "moral_equivalence": "conceptual",
            "alternative_perspective": "perspectival",
            "unintended_consequences": "consequential",
            "cost_benefit": "pragmatic"
        }
        
    def generate_counterpoints(
        self, 
        argument: str, 
        topic: str = "",
        count: int = 3
    ) -> Dict[str, Any]:
        """
        Generate counterpoints to an argument.
        
        Args:
            argument: The argument text to counter
            topic: Optional topic context
            count: Number of counterpoints to generate
            
        Returns:
            Dict containing generated counterpoints and analysis
        """
        # Extract key components from the argument
        components = self._analyze_argument(argument, topic)
        
        # Generate counterpoints based on complexity level
        counterpoints = []
        
        # Determine which strategies to use based on complexity level
        strategies = self._select_strategies(components)
        
        # Generate counterpoints for each selected strategy
        for strategy in strategies[:count]:
            counterpoint = self._generate_counterpoint(components, strategy)
            if counterpoint:
                counterpoints.append(counterpoint)
        
        # If we couldn't generate enough counterpoints, fill with generic ones
        while len(counterpoints) < count:
            generic = self._generate_generic_counterpoint(components)
            if generic:
                counterpoints.append(generic)
            
        # Determine the strongest counterpoint
        strongest_counterpoint = self._find_strongest_counterpoint(counterpoints)
        
        # Calculate rebuttal difficulty
        rebuttal_difficulty = self._calculate_rebuttal_difficulty(counterpoints, components)
        
        return {
            "counterpoints": counterpoints,
            "strongest_counterpoint": strongest_counterpoint,
            "rebuttal_difficulty": rebuttal_difficulty,
            "argument_summary": components["claim"]
        }
    
    def _analyze_argument(self, argument: str, topic: str = "") -> Dict[str, Any]:
        """
        Extract key components from the argument for targeted counterpoints.
        
        Args:
            argument: The argument text to analyze
            topic: Optional topic context
            
        Returns:
            Dict containing extracted components
        """
        sentences = [s.strip() for s in argument.split('.') if s.strip()]
        
        # Try to identify the main claim
        claim = sentences[0] if sentences else argument
        
        # Extract potential evidence
        evidence = []
        for sentence in sentences[1:]:
            lower_sent = sentence.lower()
            if any(marker in lower_sent for marker in ["because", "since", "given that", "research", "studies", "data", "evidence", "according to", "example"]):
                evidence.append(sentence)
        
        # Extract potential causes/effects for causal arguments
        causal_components = []
        for sentence in sentences:
            if any(marker in sentence.lower() for marker in ["cause", "effect", "result", "lead to", "due to", "impact"]):
                causal_components.append(sentence)
        
        # Look for comparisons or analogies
        comparisons = []
        for sentence in sentences:
            if any(marker in sentence.lower() for marker in ["like", "similar", "just as", "compared to", "analogy"]):
                comparisons.append(sentence)
        
        # Look for policy proposals
        proposals = []
        for sentence in sentences:
            if any(marker in sentence.lower() for marker in ["should", "must", "need to", "recommend", "propose", "policy", "implement"]):
                proposals.append(sentence)
        
        # Use topic if available and claim is short
        if topic and len(claim) < 50:
            enhanced_claim = f"{claim} regarding {topic}"
        else:
            enhanced_claim = claim
            
        return {
            "claim": enhanced_claim,
            "evidence": evidence,
            "causal_components": causal_components,
            "comparisons": comparisons,
            "proposals": proposals,
            "full_text": argument,
            "topic": topic
        }
    
    def _select_strategies(self, components: Dict[str, Any]) -> List[str]:
        """
        Select appropriate counterargument strategies based on argument components.
        
        Args:
            components: Extracted argument components
            
        Returns:
            List of selected strategy names
        """
        available_strategies = []
        
        # Evidence challenge if evidence is provided
        if components["evidence"]:
            available_strategies.append("evidence_challenge")
        
        # Causal fallacy if causal reasoning is present
        if components["causal_components"]:
            available_strategies.append("causal_fallacy")
        
        # False dichotomy challenge (general strategy, can apply broadly)
        available_strategies.append("false_dichotomy")
        
        # Slippery slope when proposals are made
        if components["proposals"]:
            available_strategies.append("slippery_slope")
            available_strategies.append("unintended_consequences")
            available_strategies.append("cost_benefit")
        
        # Moral equivalence when comparisons are made
        if components["comparisons"]:
            available_strategies.append("moral_equivalence")
        
        # Always include alternative perspective
        available_strategies.append("alternative_perspective")
        
        # Shuffle strategies for variety
        random.shuffle(available_strategies)
        
        # Select subset based on complexity level
        if self.level == 1:
            # Basic level: use the first 2 strategies, prioritizing simpler ones
            simple_strategies = ["evidence_challenge", "alternative_perspective"]
            selected = [s for s in available_strategies if s in simple_strategies]
            return (selected + available_strategies)[:2]
        elif self.level == 2:
            # Intermediate level: use first 3-4 strategies
            return available_strategies[:min(4, len(available_strategies))]
        else:
            # Advanced level: use all available strategies up to 5
            return available_strategies[:min(5, len(available_strategies))]
    
    def _generate_counterpoint(self, components: Dict[str, Any], strategy: str) -> Dict[str, Any]:
        """
        Generate a counterpoint using a specific strategy.
        
        Args:
            components: Extracted argument components
            strategy: Strategy to apply
            
        Returns:
            Dict containing counterpoint details
        """
        if strategy not in self.strategy_templates:
            return None
            
        templates = self.strategy_templates[strategy]
        template = random.choice(templates)
        
        # Generate content based on strategy
        if strategy == "evidence_challenge":
            return self._generate_evidence_challenge(components, template)
        elif strategy == "causal_fallacy":
            return self._generate_causal_fallacy(components, template)
        elif strategy == "false_dichotomy":
            return self._generate_false_dichotomy(components, template)
        elif strategy == "slippery_slope":
            return self._generate_slippery_slope(components, template)
        elif strategy == "moral_equivalence":
            return self._generate_moral_equivalence(components, template)
        elif strategy == "alternative_perspective":
            return self._generate_alternative_perspective(components, template)
        elif strategy == "unintended_consequences":
            return self._generate_unintended_consequences(components, template)
        elif strategy == "cost_benefit":
            return self._generate_cost_benefit(components, template)
        
        return None
        
    def _generate_evidence_challenge(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate an evidence challenge counterpoint."""
        claim = components["claim"]
        
        # Potential challenges to evidence
        challenges = [
            "it relies on outdated information",
            "the sample size is too small to be representative",
            "correlation doesn't imply causation in this case",
            "it fails to account for important factors",
            "the source is potentially biased",
            "it cherry-picks data points that support the conclusion",
            "it lacks peer-reviewed research support",
            "anecdotal evidence cannot be generalized"
        ]
        
        reason = random.choice(challenges)
        
        text = template.format(claim=claim, reason=reason)
        
        return {
            "text": text,
            "strategy": "evidence_challenge",
            "attack_type": self.attack_types["evidence_challenge"]
        }
        
    def _generate_causal_fallacy(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate a causal fallacy counterpoint."""
        claim = components["claim"]
        
        # Extract cause and effect if possible
        cause = "the proposed cause"
        effect = "the claimed effect"
        
        if components["causal_components"]:
            causal_text = random.choice(components["causal_components"])
            cause_effect = causal_text.split(" leads to ")
            if len(cause_effect) == 2:
                cause, effect = cause_effect
            else:
                cause_effect = causal_text.split(" results in ")
                if len(cause_effect) == 2:
                    cause, effect = cause_effect
        
        # Alternative explanations
        alternatives = [
            "there may be a third factor influencing both",
            "the relationship is more complex and multifaceted",
            "the correlation is coincidental rather than causal",
            "the causation may actually run in the opposite direction",
            "multiple factors working in combination are responsible"
        ]
        
        alternative = random.choice(alternatives)
        
        text = template.format(claimed_cause=cause, effect=effect, alternative=alternative)
        
        return {
            "text": text,
            "strategy": "causal_fallacy",
            "attack_type": self.attack_types["causal_fallacy"]
        }
        
    def _generate_false_dichotomy(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate a false dichotomy counterpoint."""
        claim = components["claim"]
        
        # Generate plausible options based on the claim or topic
        if "either" in claim.lower() and "or" in claim.lower():
            parts = claim.lower().split("either ")
            if len(parts) > 1:
                options_part = parts[1].split(" or ")
                if len(options_part) > 1:
                    option1 = options_part[0]
                    option2 = options_part[1].split(".")[0]
                else:
                    option1 = "the first option"
                    option2 = "the second option"
            else:
                option1 = "the first option"
                option2 = "the second option"
        else:
            # Generate generic options
            topic = components["topic"] if components["topic"] else "this issue"
            option1 = f"completely supporting {topic}"
            option2 = f"completely opposing {topic}"
        
        # Alternative approaches
        alternatives = [
            f"there are many middle-ground positions that could be more effective",
            f"a more nuanced approach combines elements of both while avoiding extremes",
            f"the issue requires a case-by-case analysis rather than a one-size-fits-all solution",
            f"we should consider a third approach that addresses the limitations of both options"
        ]
        
        alternative = random.choice(alternatives)
        
        text = template.format(option1=option1, option2=option2, alternative=alternative)
        
        return {
            "text": text,
            "strategy": "false_dichotomy",
            "attack_type": self.attack_types["false_dichotomy"]
        }
        
    def _generate_slippery_slope(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate a slippery slope counterpoint."""
        # Extract initial action from proposals if available
        initial_action = "the proposed action"
        if components["proposals"]:
            proposal = random.choice(components["proposals"])
            initial_action = proposal
        
        # Create extreme outcome based on topic or claim
        topic = components["topic"] if components["topic"] else "the issue"
        extreme_outcomes = [
            f"a complete breakdown of {topic}",
            f"disastrous consequences for {topic}",
            f"an irreversible harm to society",
            f"the loss of fundamental rights",
            f"catastrophic systemic failure"
        ]
        extreme_outcome = random.choice(extreme_outcomes)
        
        # Rebuttals to slippery slope
        rebuttals = [
            "regulatory safeguards can prevent such extreme outcomes",
            "there are natural limiting factors that prevent such escalation",
            "historical precedent shows that such fears are overblown",
            "we can implement the proposal in stages with evaluation at each step",
            "similar policies have been implemented elsewhere without such consequences"
        ]
        rebuttal = random.choice(rebuttals)
        
        text = template.format(
            initial_action=initial_action,
            extreme_outcome=extreme_outcome,
            rebuttal=rebuttal
        )
        
        return {
            "text": text,
            "strategy": "slippery_slope",
            "attack_type": self.attack_types["slippery_slope"]
        }
        
    def _generate_moral_equivalence(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate a moral equivalence counterpoint."""
        # Extract situations being compared if available
        situation1 = "the first situation"
        situation2 = "the second situation"
        
        if components["comparisons"]:
            comparison = random.choice(components["comparisons"])
            parts = comparison.lower().split(" like ")
            if len(parts) > 1:
                situation1 = parts[0].strip()
                situation2 = parts[1].strip().split(",")[0].strip()
        else:
            # Use topic as basis for comparison
            topic = components["topic"] if components["topic"] else "this case"
            situation1 = topic
            situation2 = f"a simplified version of {topic}"
        
        # Distinctions between compared situations
        distinctions = [
            "the contexts are fundamentally different",
            "the scale and scope of impacts differ significantly",
            "the intent and purpose behind each are not comparable",
            "historical and social factors make the comparison inappropriate",
            "ethical considerations apply differently in each case"
        ]
        distinction = random.choice(distinctions)
        
        text = template.format(
            situation1=situation1,
            situation2=situation2,
            distinction=distinction
        )
        
        return {
            "text": text,
            "strategy": "moral_equivalence",
            "attack_type": self.attack_types["moral_equivalence"]
        }
        
    def _generate_alternative_perspective(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate an alternative perspective counterpoint."""
        claim = components["claim"]
        
        # Potential perspectives
        perspectives = [
            "economic efficiency",
            "social justice",
            "environmental sustainability",
            "individual liberty",
            "cultural values",
            "historical precedent",
            "technological innovation",
            "global cooperation"
        ]
        perspective = random.choice(perspectives)
        
        # Alternative views based on different perspectives
        alternative_views = [
            f"we see different priorities emerge that challenge the original premise",
            f"the argument's assumptions are revealed to be culturally biased",
            f"the short-term benefits are overshadowed by long-term concerns",
            f"the proposed approach fails to address key stakeholder needs",
            f"the evidence supports a different conclusion entirely"
        ]
        alternative_view = random.choice(alternative_views)
        
        # Possible alternative outcomes
        alternative_outcomes = [
            "different outcomes than those predicted",
            "unintended consequences that undermine the original goal",
            "a solution that satisfies neither side of the debate",
            "temporary benefits but long-term problems",
            "benefits for some groups but harms for others"
        ]
        alternative_outcome = random.choice(alternative_outcomes)
        
        if "alternative_view" in template:
            text = template.format(
                claim=claim,
                perspective=perspective,
                alternative_view=alternative_view
            )
        else:
            text = template.format(
                claim=claim,
                alternative_outcome=alternative_outcome
            )
        
        return {
            "text": text,
            "strategy": "alternative_perspective",
            "attack_type": self.attack_types["alternative_perspective"]
        }
        
    def _generate_unintended_consequences(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate an unintended consequences counterpoint."""
        # Extract proposal if available
        proposal = "the proposed approach"
        if components["proposals"]:
            proposal = random.choice(components["proposals"])
            
        # Generate intended outcome
        topic = components["topic"] if components["topic"] else "the issue"
        intended_outcomes = [
            f"improving {topic}",
            f"solving the problems with {topic}",
            f"addressing concerns about {topic}",
            f"making progress on {topic}",
            f"achieving the stated goals"
        ]
        intended_outcome = random.choice(intended_outcomes)
        
        # Potential negative consequences
        negative_consequences = [
            "creating perverse incentives that worsen the original problem",
            "disproportionately harming vulnerable populations",
            "excessive implementation costs that drain resources from other priorities",
            "regulatory overreach that stifles innovation and adaptation",
            "establishing precedents that could be misused in other contexts",
            "creating a false sense of security while ignoring root causes"
        ]
        negative_consequence = random.choice(negative_consequences)
        
        text = template.format(
            proposal=proposal,
            intended_outcome=intended_outcome,
            negative_consequence=negative_consequence
        )
        
        return {
            "text": text,
            "strategy": "unintended_consequences",
            "attack_type": self.attack_types["unintended_consequences"]
        }
        
    def _generate_cost_benefit(self, components: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Generate a cost-benefit counterpoint."""
        # Extract proposal if available
        proposal = "the proposed approach"
        if components["proposals"]:
            proposal = random.choice(components["proposals"])
            
        # Potential costs
        costs = [
            "financial burdens that outweigh any potential benefits",
            "social disruption that would require years of adjustment",
            "the opportunity cost of not pursuing alternative solutions",
            "implementation challenges that make it impractical",
            "compliance costs that would be passed on to those who can least afford them",
            "reductions in flexibility that prevent adapting to changing circumstances"
        ]
        cost = random.choice(costs)
        
        text = template.format(proposal=proposal, costs=cost)
        
        return {
            "text": text,
            "strategy": "cost_benefit",
            "attack_type": self.attack_types["cost_benefit"]
        }
        
    def _generate_generic_counterpoint(self, components: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a generic counterpoint when specific strategies aren't applicable."""
        claim = components["claim"]
        
        # Generic counterpoint templates
        templates = [
            f"The argument that {claim} fails to consider important alternatives.",
            f"While {claim} has some merit, it overlooks critical factors that lead to a different conclusion.",
            f"The reasoning behind {claim} contains logical gaps that undermine its conclusion.",
            f"A more careful analysis of {claim} reveals flaws in its underlying assumptions."
        ]
        
        text = random.choice(templates)
        
        return {
            "text": text,
            "strategy": "generic_challenge",
            "attack_type": "general"
        }
        
    def _find_strongest_counterpoint(self, counterpoints: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Determine the strongest counterpoint based on strategy effectiveness.
        
        Args:
            counterpoints: List of generated counterpoints
            
        Returns:
            Dict representing the strongest counterpoint
        """
        if not counterpoints:
            return None
            
        # Strategy strength rankings (higher is stronger)
        strategy_strength = {
            "evidence_challenge": 5,
            "causal_fallacy": 4,
            "false_dichotomy": 3,
            "moral_equivalence": 3,
            "alternative_perspective": 2,
            "slippery_slope": 4,
            "unintended_consequences": 5,
            "cost_benefit": 4,
            "generic_challenge": 1
        }
        
        # Find counterpoint with highest strength score
        strongest = max(counterpoints, key=lambda cp: strategy_strength.get(cp["strategy"], 0))
        return strongest
        
    def _calculate_rebuttal_difficulty(
        self, 
        counterpoints: List[Dict[str, Any]], 
        components: Dict[str, Any]
    ) -> float:
        """
        Calculate how difficult it would be to rebut these counterpoints.
        
        Args:
            counterpoints: List of generated counterpoints
            components: Extracted argument components
            
        Returns:
            Difficulty score (0-1)
        """
        if not counterpoints:
            return 0.0
            
        # Base difficulty by level
        base_difficulty = 0.3 * self.level
        
        # Add difficulty based on evidence presence
        if not components["evidence"]:
            base_difficulty += 0.2  # Harder to rebut without evidence
            
        # Add difficulty based on strongest counterpoint
        strongest = self._find_strongest_counterpoint(counterpoints)
        if strongest:
            strategy_difficulty = {
                "evidence_challenge": 0.2,
                "causal_fallacy": 0.15,
                "false_dichotomy": 0.1,
                "moral_equivalence": 0.1,
                "alternative_perspective": 0.05,
                "slippery_slope": 0.1,
                "unintended_consequences": 0.15,
                "cost_benefit": 0.15,
                "generic_challenge": 0.05
            }
            
            base_difficulty += strategy_difficulty.get(strongest["strategy"], 0)
            
        # Cap at 1.0
        return min(1.0, base_difficulty)