"""
Socratic Questioner for AI Debate Coach
Generates probing questions that challenge assumptions in arguments.
"""
import re
import random
from typing import List, Dict, Any

class SocraticQuestioner:
    """Generates probing questions using Socratic method."""
    
    def __init__(self):
        """Initialize the Socratic questioner with question templates."""
        # Question templates organized by category
        self.question_templates = {
            "clarification": [
                "What do you mean by {term}?",
                "Could you explain {term} in more detail?",
                "How would you define {term} in this context?",
                "What is your understanding of {term}?",
                "Can you elaborate on what {term} means here?"
            ],
            "assumption": [
                "What are you assuming when you say {statement}?",
                "Is it always true that {statement}?",
                "Are there any unstated assumptions in your claim that {statement}?",
                "What justifies the assumption that {statement}?",
                "Could your assumption that {statement} be challenged?"
            ],
            "evidence": [
                "What evidence supports your claim that {statement}?",
                "How do you know that {statement}?",
                "Is there research that confirms {statement}?",
                "What sources validate your assertion that {statement}?",
                "Could you point to specific data that demonstrates {statement}?"
            ],
            "alternative": [
                "Are there alternative explanations for {phenomenon}?",
                "Have you considered other perspectives on {phenomenon}?",
                "What would someone who disagrees with you say about {phenomenon}?",
                "Could there be other ways to interpret {phenomenon}?",
                "What are some other possible ways to understand {phenomenon}?"
            ],
            "implication": [
                "If {statement} is true, what else must be true?",
                "What are the consequences if everyone followed your reasoning about {statement}?",
                "Where does your position on {statement} ultimately lead?",
                "What might be some unintended results of {statement}?",
                "How does your conclusion about {statement} affect other related issues?"
            ],
            "counter": [
                "What would be a strong objection to your position that {statement}?",
                "How would you respond to someone who argues that {counter_position}?",
                "What is the best argument against your view that {statement}?",
                "Why might someone reasonably disagree with your claim that {statement}?",
                "What weaknesses might critics identify in your position that {statement}?"
            ],
            "example": [
                "Can you give a concrete example that illustrates {statement}?",
                "How would your argument apply in the specific case of {example_scenario}?",
                "Could you provide a real-world example that demonstrates {statement}?",
                "What's a practical example that shows how {statement} works?",
                "How would this play out in a situation like {example_scenario}?"
            ],
            "distinction": [
                "What's the difference between {term1} and {term2} in your argument?",
                "How do you distinguish between {term1} and {term2}?",
                "Could someone confuse {term1} with {term2}, and how would you clarify?",
                "Are there important distinctions between {term1} and {term2} that affect your conclusion?",
                "Why is it important to separate {term1} from {term2} in this context?"
            ]
        }
        
        # Keywords that might indicate assumptions or key terms
        self.assumption_indicators = [
            "obviously", "clearly", "certainly", "naturally", "of course",
            "undoubtedly", "inevitably", "necessarily", "always", "never",
            "everyone", "no one", "all", "none", "must", "should", "only"
        ]
        
    def generate_questions(self, argument: str, count: int = 3) -> List[Dict[str, Any]]:
        """
        Generate Socratic questions based on the argument text.
        
        Args:
            argument: The argument text to analyze
            count: Number of questions to generate
            
        Returns:
            List of dicts containing questions and their categories
        """
        # Analyze the argument to extract key components
        analysis = self._analyze_argument(argument)
        
        # Generate questions for different categories
        all_questions = []
        
        # Clarification questions about key terms
        if analysis["key_terms"]:
            for term in analysis["key_terms"][:2]:  # Limit to top 2 terms
                template = random.choice(self.question_templates["clarification"])
                all_questions.append({
                    "question": template.format(term=term),
                    "category": "clarification",
                    "target": term,
                    "purpose": "To clarify understanding of key terms in the argument"
                })
        
        # Assumption questions
        if analysis["assumptions"]:
            for assumption in analysis["assumptions"][:2]:  # Limit to top 2 assumptions
                template = random.choice(self.question_templates["assumption"])
                all_questions.append({
                    "question": template.format(statement=assumption),
                    "category": "assumption",
                    "target": assumption,
                    "purpose": "To examine unstated premises in the argument"
                })
                
        # Evidence questions about the main claim
        if analysis["claim"]:
            template = random.choice(self.question_templates["evidence"])
            all_questions.append({
                "question": template.format(statement=analysis["claim"]),
                "category": "evidence",
                "target": analysis["claim"],
                "purpose": "To examine the factual basis of the central claim"
            })
            
        # Alternative perspective questions
        if analysis["phenomena"]:
            for phenomenon in analysis["phenomena"][:2]:  # Limit to top 2
                template = random.choice(self.question_templates["alternative"])
                all_questions.append({
                    "question": template.format(phenomenon=phenomenon),
                    "category": "alternative",
                    "target": phenomenon,
                    "purpose": "To consider different viewpoints on the issue"
                })
                
        # Implication questions about the conclusion
        if analysis["conclusion"]:
            template = random.choice(self.question_templates["implication"])
            all_questions.append({
                "question": template.format(statement=analysis["conclusion"]),
                "category": "implication",
                "target": analysis["conclusion"],
                "purpose": "To explore logical consequences of the argument"
            })
        elif analysis["claim"]:  # Fall back to claim if no conclusion
            template = random.choice(self.question_templates["implication"])
            all_questions.append({
                "question": template.format(statement=analysis["claim"]),
                "category": "implication",
                "target": analysis["claim"],
                "purpose": "To explore logical consequences of the argument"
            })
            
        # Counter questions based on predicted counter-positions
        if analysis["counter_positions"]:
            for counter in analysis["counter_positions"][:2]:  # Limit to top 2
                template = random.choice(self.question_templates["counter"])
                all_questions.append({
                    "question": template.format(
                        statement=analysis["claim"],
                        counter_position=counter
                    ),
                    "category": "counter",
                    "target": counter,
                    "purpose": "To anticipate and address potential objections"
                })
        
        # Example questions to make argument more concrete
        if analysis["claim"]:
            # Generate example scenarios based on the topic
            example_scenarios = self._generate_example_scenarios(analysis)
            if example_scenarios:
                scenario = random.choice(example_scenarios)
                template = random.choice(self.question_templates["example"])
                all_questions.append({
                    "question": template.format(
                        statement=analysis["claim"],
                        example_scenario=scenario
                    ),
                    "category": "example",
                    "target": scenario,
                    "purpose": "To ground abstract concepts in concrete examples"
                })
                
        # Distinction questions to clarify terminology
        if len(analysis["key_terms"]) >= 2:
            term1 = analysis["key_terms"][0]
            term2 = analysis["key_terms"][1]
            template = random.choice(self.question_templates["distinction"])
            all_questions.append({
                "question": template.format(term1=term1, term2=term2),
                "category": "distinction",
                "target": f"{term1}, {term2}",
                "purpose": "To clarify important conceptual distinctions"
            })
                
        # If we couldn't generate enough questions, add generic ones
        if len(all_questions) < count:
            generic_questions = self._generate_generic_questions(analysis["claim"], count - len(all_questions))
            all_questions.extend(generic_questions)
            
        # Shuffle and return the requested number of questions
        random.shuffle(all_questions)
        return all_questions[:count]
    
    def _analyze_argument(self, text: str) -> Dict[str, Any]:
        """Analyze an argument to extract components for question generation."""
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        
        # Simple approach: first sentence is often the claim
        claim = sentences[0] if sentences else ""
        
        # Last sentence might be the conclusion
        conclusion = sentences[-1] if len(sentences) > 1 else ""
        
        # Extract potential key terms (longer words that might be important)
        words = text.lower().split()
        potential_terms = [
            word for word in words 
            if len(word) > 5 and word.isalpha() and word not in [
                "because", "therefore", "however", "although", "though"
            ]
        ]
        
        # Count frequency to find key terms
        term_counts = {}
        for term in potential_terms:
            if term in term_counts:
                term_counts[term] += 1
            else:
                term_counts[term] = 1
                
        # Get top terms by frequency
        key_terms = sorted(term_counts.keys(), key=lambda t: term_counts[t], reverse=True)[:5]
        
        # Find potential assumptions (sentences with indicator words)
        assumptions = []
        for sentence in sentences:
            sentence_lower = sentence.lower()
            if any(indicator in sentence_lower for indicator in self.assumption_indicators):
                assumptions.append(sentence)
                
        # Extract phenomena (things being explained or analyzed)
        phenomena = []
        for sentence in sentences:
            if "is" in sentence or "are" in sentence:
                parts = re.split(r'\s+is\s+|\s+are\s+', sentence, 1)
                if len(parts) > 1:
                    # The subject might be a phenomenon being explained
                    phenomena.append(parts[0].strip())
                    
        # Generate potential counter-positions
        counter_positions = self._generate_counter_positions(claim, conclusion)
        
        # Determine the topic of the argument
        topic = self._extract_topic(text, key_terms)
        
        return {
            "claim": claim,
            "conclusion": conclusion,
            "key_terms": key_terms,
            "assumptions": assumptions,
            "phenomena": phenomena,
            "counter_positions": counter_positions,
            "topic": topic
        }
    
    def _extract_topic(self, text: str, key_terms: List[str]) -> str:
        """Extract the main topic from the argument."""
        # Check for common topic indicators
        topic_indicators = ["regarding", "about", "concerning", "on the topic of", "on the issue of"]
        
        for indicator in topic_indicators:
            if indicator in text.lower():
                parts = text.lower().split(indicator, 1)
                if len(parts) > 1:
                    # Take the first few words after the indicator
                    topic_part = parts[1].strip().split()[:3]
                    return " ".join(topic_part)
        
        # If no explicit indicator, use the most frequent key term
        if key_terms:
            return key_terms[0]
        
        return ""
    
    def _generate_counter_positions(self, claim: str, conclusion: str) -> List[str]:
        """Generate potential counter-positions to the argument."""
        counter_positions = []
        
        # Simple negation of claim
        if claim:
            # Replace affirmative statements with negations and vice versa
            negated = self._negate_statement(claim)
            if negated:
                counter_positions.append(negated)
                
        # Alternative to conclusion
        if conclusion and conclusion != claim:
            negated = self._negate_statement(conclusion)
            if negated:
                counter_positions.append(negated)
                
        # Add some generic counter-positions if needed
        if len(counter_positions) < 2:
            counter_positions.append("the evidence provided is insufficient")
            counter_positions.append("there are more important factors to consider")
            counter_positions.append("the proposed solution has significant drawbacks")
            counter_positions.append("the argument overlooks critical ethical considerations")
            
        return counter_positions
    
    def _negate_statement(self, statement: str) -> str:
        """Create a negated version of a statement."""
        statement_lower = statement.lower()
        
        # Handle common statement patterns
        if " is " in statement_lower:
            return statement.replace(" is ", " is not ", 1)
        elif " are " in statement_lower:
            return statement.replace(" are ", " are not ", 1)
        elif " will " in statement_lower:
            return statement.replace(" will ", " will not ", 1)
        elif " can " in statement_lower:
            return statement.replace(" can ", " cannot ", 1)
        elif " should " in statement_lower:
            return statement.replace(" should ", " should not ", 1)
        elif " must " in statement_lower:
            return statement.replace(" must ", " must not ", 1)
        elif " has " in statement_lower:
            return statement.replace(" has ", " does not have ", 1)
        elif " have " in statement_lower:
            return statement.replace(" have ", " do not have ", 1)
        elif " do " in statement_lower:
            return statement.replace(" do ", " do not ", 1)
        elif " does " in statement_lower:
            return statement.replace(" does ", " does not ", 1)
        elif statement_lower.startswith("it is "):
            return statement.replace("It is ", "It is not ", 1).replace("it is ", "it is not ", 1)
        elif statement_lower.startswith("there is "):
            return statement.replace("There is ", "There is no ", 1).replace("there is ", "there is no ", 1)
        elif statement_lower.startswith("there are "):
            return statement.replace("There are ", "There are no ", 1).replace("there are ", "there are no ", 1)
            
        # If no pattern matched, return empty string
        return ""
    
    def _generate_example_scenarios(self, analysis: Dict[str, Any]) -> List[str]:
        """Generate example scenarios based on the argument topic."""
        topic = analysis["topic"]
        
        if not topic:
            return []
            
        # Create scenarios related to common domains
        scenarios = [
            f"a local community dealing with {topic}",
            f"a policy decision about {topic} in a large organization",
            f"educational settings where {topic} is being taught",
            f"international negotiations concerning {topic}",
            f"individual decision-making about {topic} in daily life"
        ]
        
        return scenarios
    
    def _generate_generic_questions(self, claim: str, count: int) -> List[Dict[str, Any]]:
        """Generate generic Socratic questions when specific ones can't be extracted."""
        generic_questions = [
            {
                "question": "What do you think is the strongest counterargument to your position?",
                "category": "counter",
                "target": "general",
                "purpose": "To anticipate and address potential objections"
            },
            {
                "question": "How would you respond to someone who disagrees with your conclusion?",
                "category": "counter",
                "target": "general",
                "purpose": "To anticipate and address potential objections"
            },
            {
                "question": "What evidence would change your mind on this issue?",
                "category": "evidence",
                "target": "general",
                "purpose": "To examine the factual basis and evaluate open-mindedness"
            },
            {
                "question": "Are there any weaknesses in your argument that you're aware of?",
                "category": "assumption",
                "target": "general",
                "purpose": "To encourage self-critique and strengthen reasoning"
            },
            {
                "question": "How might your personal values or experiences influence your position?",
                "category": "bias",
                "target": "general",
                "purpose": "To examine potential biases in reasoning"
            },
            {
                "question": "What are the practical implications if your view were widely adopted?",
                "category": "implication",
                "target": "general",
                "purpose": "To explore logical consequences of the argument"
            }
        ]
        
        if claim:
            generic_questions.extend([
                {
                    "question": f"Why do you believe that {claim}?",
                    "category": "evidence",
                    "target": claim,
                    "purpose": "To explore the foundations of the central claim"
                },
                {
                    "question": f"How confident are you that {claim}, and why?",
                    "category": "evidence",
                    "target": claim,
                    "purpose": "To assess confidence and reasoning"
                }
            ])
            
        # Shuffle and return the requested number
        random.shuffle(generic_questions)
        return generic_questions[:count]
    
    def get_question_categories(self) -> Dict[str, str]:
        """Return descriptions of the question categories."""
        return {
            "clarification": "Questions that clarify concepts and definitions",
            "assumption": "Questions that probe assumptions and premises",
            "evidence": "Questions that examine evidence and reasons",
            "alternative": "Questions that consider alternative viewpoints",
            "implication": "Questions that explore implications and consequences",
            "counter": "Questions that challenge the position with counterarguments",
            "bias": "Questions that examine potential biases",
            "example": "Questions that request concrete examples",
            "distinction": "Questions that clarify conceptual distinctions"
        }