"""
Argument Validator for AI Debate Coach
Detects logical fallacies and evaluates argument validity.
"""
from typing import List, Dict, Any
import re
import logging

class ArgumentValidator:
    """Detects logical fallacies and validates debate arguments."""
    
    def __init__(self):
        """Initialize the argument validator with fallacy patterns."""
        # Dictionary of common fallacy patterns and their descriptions
        self.fallacy_patterns = {
            "ad_hominem": {
                "patterns": ["attack", "person", "character", "stupid", "idiot", "incompetent", "fool"],
                "description": "Attacking the person instead of addressing their argument",
                "example": "We can't trust her research because she's politically biased",
                "severity": 0.8
            },
            "straw_man": {
                "patterns": ["not what", "didn't say", "misrepresent", "exaggerat", "caricature"],
                "description": "Misrepresenting an opponent's argument to make it easier to attack",
                "example": "You think we should let everyone in the country without checking",
                "severity": 0.7
            },
            "false_dichotomy": {
                "patterns": ["either", "or", "only two", "only choice", "black and white", "false choice"],
                "description": "Presenting only two options when others exist",
                "example": "Either we cut taxes or the economy will collapse",
                "severity": 0.6
            },
            "appeal_to_authority": {
                "patterns": ["expert", "authority", "professor", "doctor", "scientist said", "research says", "studies show"],
                "description": "Using an authority figure to support an argument without providing evidence",
                "example": "Dr. Smith says this treatment works, so it must be effective",
                "severity": 0.5
            },
            "slippery_slope": {
                "patterns": ["lead to", "next thing", "first step", "eventually", "ultimately", "slippery slope"],
                "description": "Asserting that a small step will lead to significant negative consequences",
                "example": "If we allow this exception, soon there will be no rules at all",
                "severity": 0.6
            },
            "hasty_generalization": {
                "patterns": ["all", "every", "always", "never", "everyone", "nobody", "without exception"],
                "description": "Making a general claim based on insufficient evidence",
                "example": "I met three rude people from that city, so everyone there is unfriendly",
                "severity": 0.7
            },
            "circular_reasoning": {
                "patterns": ["because it is", "by definition", "we know", "clearly", "obviously"],
                "description": "Using a claim to support itself without additional evidence",
                "example": "This policy is good because it produces good outcomes",
                "severity": 0.7
            },
            "ad_populum": {
                "patterns": ["everyone knows", "most people", "popular opinion", "majority", "commonly accepted"],
                "description": "Appealing to popularity rather than evidence to support a claim",
                "example": "Most people agree that this approach is best, so we should adopt it",
                "severity": 0.5
            },
            "false_causality": {
                "patterns": ["caused by", "because of", "leads to", "results in", "due to"],
                "description": "Assuming causation when only correlation is established",
                "example": "Crime went down when we implemented this policy, so the policy reduced crime",
                "severity": 0.6
            },
            "appeal_to_emotion": {
                "patterns": ["outrageous", "shocking", "terrifying", "heartbreaking", "devastating", "feel", "emotions"],
                "description": "Using emotional appeals instead of logical reasoning",
                "example": "Think of the children who will suffer if you don't support this initiative",
                "severity": 0.5
            }
        }
    
    def validate_argument(self, argument_text: str) -> Dict[str, Any]:
        """
        Validate an argument for logical fallacies and other issues.
        
        Args:
            argument_text: The text of the argument to validate
            
        Returns:
            Dict containing validation results and detected fallacies
        """
        # Check for various fallacies
        detected_fallacies = self._detect_fallacies(argument_text)
        
        # Evaluate structural integrity
        structure_analysis = self._analyze_structure(argument_text)
        
        # Analyze patterns of reasoning
        reasoning_analysis = self._analyze_reasoning(argument_text)
        
        # Calculate overall validity score
        validity_score = self._calculate_validity_score(detected_fallacies, structure_analysis, reasoning_analysis)
        
        # Generate improvement suggestions
        suggestions = self._generate_suggestions(detected_fallacies, structure_analysis, reasoning_analysis)
        
        return {
            "validity_score": validity_score,
            "detected_fallacies": detected_fallacies,
            "structure_analysis": structure_analysis,
            "reasoning_analysis": reasoning_analysis,
            "improvement_suggestions": suggestions
        }
    
    def _detect_fallacies(self, text: str) -> List[Dict[str, Any]]:
        """Detect logical fallacies in the argument text."""
        text_lower = text.lower()
        detected = []
        
        for fallacy_name, fallacy_info in self.fallacy_patterns.items():
            for pattern in fallacy_info["patterns"]:
                pattern_regex = r'\b' + re.escape(pattern.lower()) + r'\b'
                match = re.search(pattern_regex, text_lower)
                if match:
                    start_pos = max(0, match.start() - 20)
                    end_pos = min(len(text_lower), match.end() + 20)
                    context = text_lower[start_pos:end_pos]
                    detected.append({
                        "fallacy_type": fallacy_name,
                        "description": fallacy_info["description"],
                        "matched_pattern": pattern,
                        "example": fallacy_info["example"],
                        "severity": fallacy_info["severity"],
                        "context": "..." + context + "..."
                    })
                    break  # Once a pattern for this fallacy is matched, move to next fallacy
        
        return detected
    
    def _analyze_structure(self, text: str) -> Dict[str, Any]:
        """Analyze the structural integrity of the argument."""
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        
        # Basic structure analysis
        has_claim = any(any(indicator in sentence.lower() for indicator in ["argue", "claim", "assert", "believe", "think", "position", "view"])
                        for sentence in sentences)
        # If no explicit claim indicator found, assume first sentence is claim (if exists)
        if not has_claim and sentences:
            has_claim = True
        
        evidence_indicators = ["because", "since", "given that", "research", "studies", "data", "evidence", "according to", "example", "instance", "case"]
        has_evidence = any(any(indicator in sentence.lower() for indicator in evidence_indicators)
                           for sentence in sentences)
        reasoning_indicators = sum(1 for sentence in sentences if any(indicator in sentence.lower() for indicator in evidence_indicators))
        
        conclusion_indicators = ["therefore", "thus", "hence", "consequently", "so", "conclude", "in conclusion", "it follows that"]
        has_conclusion = any(any(indicator in sentence.lower() for indicator in conclusion_indicators)
                             for sentence in sentences)
        if not has_conclusion and len(sentences) > 1:
            last_sentence = sentences[-1].lower()
            if any(word in last_sentence for word in ["should", "must", "need", "recommend", "propose", "advocate"]):
                has_conclusion = True
        
        sentence_lengths = [len(s.split()) for s in sentences]
        avg_sentence_length = sum(sentence_lengths) / max(1, len(sentences))
        has_proper_paragraphs = len(sentences) >= 3
        has_complete_structure = has_claim and has_evidence and has_conclusion
        
        return {
            "has_claim": has_claim,
            "has_evidence": has_evidence,
            "has_conclusion": has_conclusion,
            "reasoning_indicators": reasoning_indicators,
            "sentence_count": len(sentences),
            "average_sentence_length": avg_sentence_length,
            "has_proper_paragraphs": has_proper_paragraphs,
            "has_complete_structure": has_complete_structure
        }
    
    def _analyze_reasoning(self, text: str) -> Dict[str, Any]:
        """Analyze patterns of reasoning in the argument."""
        text_lower = text.lower()
        has_statistics = any(term in text_lower for term in ["percent", "percentage", "study", "research", "survey", "poll", "statistics", "data"])
        has_examples = any(term in text_lower for term in ["example", "instance", "case", "illustration", "for instance", "such as"])
        has_expert_opinion = any(term in text_lower for term in ["expert", "professor", "researcher", "scientist", "authority", "scholar", "professional"])
        
        has_causal_reasoning = any(term in text_lower for term in ["cause", "effect", "result", "impact", "influence", "lead to", "due to"])
        has_comparative_reasoning = any(term in text_lower for term in ["compare", "contrast", "similar", "different", "whereas", "while", "unlike", "like"])
        has_conditional_reasoning = any(term in text_lower for term in ["if", "then", "unless", "provided that", "assuming that", "given that"])
        
        acknowledges_counterarguments = any(term in text_lower for term in ["however", "but", "nevertheless", "although", "despite", "critics", "opponents", "counterargument", "objection"])
        
        evidence_types = sum([has_statistics, has_examples, has_expert_opinion])
        reasoning_patterns = sum([has_causal_reasoning, has_comparative_reasoning, has_conditional_reasoning])
        
        return {
            "evidence_types": {
                "statistics": has_statistics,
                "examples": has_examples,
                "expert_opinion": has_expert_opinion
            },
            "reasoning_patterns": {
                "causal": has_causal_reasoning,
                "comparative": has_comparative_reasoning,
                "conditional": has_conditional_reasoning
            },
            "acknowledges_counterarguments": acknowledges_counterarguments,
            "evidence_diversity": evidence_types / 3 if evidence_types > 0 else 0,
            "reasoning_diversity": reasoning_patterns / 3 if reasoning_patterns > 0 else 0
        }
    
    def _calculate_validity_score(
        self, 
        fallacies: List[Dict[str, Any]], 
        structure: Dict[str, Any],
        reasoning: Dict[str, Any]
    ) -> float:
        """Calculate an overall validity score based on fallacies, structure, and reasoning."""
        score = 0.7
        
        for fallacy in fallacies:
            score -= fallacy["severity"] * 0.15
        
        if not structure["has_claim"]:
            score -= 0.3
        if not structure["has_evidence"]:
            score -= 0.2
        if not structure["has_conclusion"]:
            score -= 0.1
        
        if structure["has_complete_structure"]:
            score += 0.15
        if structure["reasoning_indicators"] >= 2:
            score += 0.1
            
        score += reasoning["evidence_diversity"] * 0.15
        score += reasoning["reasoning_diversity"] * 0.1
        
        if reasoning["acknowledges_counterarguments"]:
            score += 0.1
            
        return max(0.0, min(1.0, score))
    
    def _generate_suggestions(
        self, 
        fallacies: List[Dict[str, Any]], 
        structure: Dict[str, Any],
        reasoning: Dict[str, Any]
    ) -> List[str]:
        """Generate improvement suggestions based on validation results."""
        suggestions = []
        
        if fallacies:
            for fallacy in fallacies[:3]:
                suggestions.append(
                    f"Avoid {fallacy['fallacy_type'].replace('_', ' ')}: {fallacy['description']}. "
                    f"Example: \"{fallacy['example']}\""
                )
        
        if not structure["has_claim"]:
            suggestions.append("Include a clear main claim or thesis statement at the beginning of your argument")
        if not structure["has_evidence"]:
            suggestions.append("Add specific evidence to support your claim (statistics, examples, or expert opinions)")
        if not structure["has_conclusion"]:
            suggestions.append("Include a conclusion that ties your evidence to your claim using words like 'therefore' or 'thus'")
        
        if structure["sentence_count"] < 3:
            suggestions.append("Expand your argument with more supporting details and evidence")
        elif structure["average_sentence_length"] > 30:
            suggestions.append("Try using shorter, clearer sentences for better comprehension")
            
        if reasoning["evidence_diversity"] < 0.34:
            suggestions.append("Diversify your evidence by including a mix of statistics, examples, and expert opinions")
            if not reasoning["evidence_types"]["statistics"]:
                suggestions.append("Consider adding statistical data to strengthen your argument")
            if not reasoning["evidence_types"]["examples"]:
                suggestions.append("Include concrete examples that illustrate your points")
            if not reasoning["evidence_types"]["expert_opinion"]:
                suggestions.append("Reference expert opinions to add credibility (but avoid appeal to authority fallacy)")
                
        if not reasoning["acknowledges_counterarguments"]:
            suggestions.append("Acknowledge potential counterarguments to strengthen your position")
            
        if reasoning["reasoning_diversity"] < 0.34:
            missing_patterns = []
            if not reasoning["reasoning_patterns"]["causal"]:
                missing_patterns.append("cause-effect relationships")
            if not reasoning["reasoning_patterns"]["comparative"]:
                missing_patterns.append("comparisons")
            if not reasoning["reasoning_patterns"]["conditional"]:
                missing_patterns.append("if-then statements")
            if missing_patterns:
                suggestions.append(f"Strengthen your reasoning by including {' and '.join(missing_patterns)}")
        
        if len(suggestions) > 5:
            fallacy_suggestions = [s for s in suggestions if "Avoid" in s]
            structure_suggestions = [s for s in suggestions if "Include a clear main claim" in s or 
                                     "Add specific evidence" in s or 
                                     "Include a conclusion" in s]
            other_suggestions = [s for s in suggestions if s not in fallacy_suggestions and s not in structure_suggestions]
            prioritized = fallacy_suggestions[:2] + structure_suggestions[:2]
            remaining_slots = 5 - len(prioritized)
            if remaining_slots > 0 and other_suggestions:
                prioritized.extend(other_suggestions[:remaining_slots])
            suggestions = prioritized
            
        return suggestions

    def highlight_fallacies(self, argument_text: str) -> Dict[str, Any]:
        """
        Create a highlighted version of text with fallacies marked.
        
        Args:
            argument_text: Original argument text
            
        Returns:
            Dict with original text and HTML-marked version highlighting fallacies
        """
        fallacies = self._detect_fallacies(argument_text)
        highlighted_text = argument_text
        
        for fallacy in fallacies:
            pattern = fallacy["matched_pattern"]
            pattern_regex = r'\b' + re.escape(pattern) + r'\b'
            replacement = (f'<span class="fallacy fallacy-{fallacy["fallacy_type"]}" '
                           f'title="{fallacy["description"]}">{pattern}</span>')
            highlighted_text = re.sub(pattern_regex, replacement, highlighted_text, flags=re.IGNORECASE)
        
        return {
            "original": argument_text,
            "highlighted": highlighted_text,
            "fallacies": fallacies
        }
