"""
Chain of Thought Processor for AI Debate Coach
Provides step-by-step reasoning for debate arguments.
"""
import re
from typing import List, Dict, Any, Tuple, Set
import random

class ChainOfThoughtProcessor:
    """Implements chain-of-thought reasoning for debate arguments."""
    
    def __init__(self, complexity_level: int = 1):
        """
        Initialize the COT processor with complexity level.
        
        Args:
            complexity_level: Controls depth of reasoning (1-3)
        """
        self.complexity_level = min(max(complexity_level, 1), 3)
        
        # Keywords that signal evidence
        self.evidence_keywords = [
            "because", "since", "given that", "research", "studies", "data", 
            "evidence", "according to", "example", "for instance", "statistics",
            "report", "survey", "expert", "findings", "analysis", "results"
        ]
        
        # Keywords that signal claim
        self.claim_keywords = [
            "argue", "claim", "assert", "believe", "think", "position", "view",
            "contend", "maintain", "hold", "propose", "suggest", "state"
        ]
        
        # Keywords that signal conclusion
        self.conclusion_keywords = [
            "therefore", "thus", "hence", "consequently", "so", "conclude", 
            "in conclusion", "it follows that", "as a result", "ultimately",
            "in summary", "clearly then", "this shows", "this demonstrates"
        ]
        
    def process_argument(self, argument_text: str) -> Dict[str, Any]:
        """
        Process an argument using chain-of-thought reasoning.
        
        Args:
            argument_text: The text of the argument to analyze
            
        Returns:
            Dict containing steps of reasoning and evaluation
        """
        # Basic clean-up of text
        clean_text = self._preprocess_text(argument_text)
        
        # Extract key components
        claim = self._extract_claim(clean_text)
        evidence = self._extract_evidence(clean_text)
        conclusion = self._extract_conclusion(clean_text)
        
        # Generate reasoning steps
        reasoning_steps = self._generate_reasoning_steps(claim, evidence, conclusion)
        
        # Evaluate argument components
        component_evaluation = self._evaluate_components(claim, evidence, conclusion)
        
        # Identify logical connections
        logical_connections = self._identify_logical_connections(claim, evidence, conclusion)
        
        # Evaluate argument quality based on reasoning steps
        validity_score = self._evaluate_validity(reasoning_steps, component_evaluation, logical_connections)
        
        # Identify key terms in the argument
        key_terms = self._extract_key_terms(clean_text)
        
        return {
            "original_argument": argument_text,
            "claim": claim,
            "evidence": evidence,
            "conclusion": conclusion,
            "key_terms": key_terms,
            "reasoning_steps": reasoning_steps,
            "component_evaluation": component_evaluation,
            "logical_connections": logical_connections,
            "validity_score": validity_score,
            "improvement_suggestions": self._generate_suggestions(validity_score, component_evaluation, logical_connections, reasoning_steps)
        }
    
    def _preprocess_text(self, text: str) -> str:
        """Clean and normalize the input text."""
        # Remove extra whitespace
        clean_text = re.sub(r'\s+', ' ', text).strip()
        return clean_text
    
    def _extract_claim(self, text: str) -> str:
        """Extract the main claim from the argument text."""
        sentences = text.split('.')
        if not sentences:
            return ""
            
        # Look for explicit claim indicators in each sentence
        for sentence in sentences:
            sentence = sentence.strip()
            if any(keyword in sentence.lower() for keyword in self.claim_keywords):
                return sentence
                
        # If no explicit claim found, use first sentence as default
        return sentences[0].strip()
    
    def _extract_evidence(self, text: str) -> List[str]:
        """Extract supporting evidence from the argument text."""
        evidence_list = []
        sentences = text.split('.')
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
                
            # Check if sentence contains evidence keywords
            if any(keyword in sentence.lower() for keyword in self.evidence_keywords):
                evidence_list.append(sentence)
        
        return evidence_list
    
    def _extract_conclusion(self, text: str) -> str:
        """Extract the conclusion from the argument text."""
        sentences = text.split('.')
        if not sentences:
            return ""
            
        # Look for explicit conclusion indicators in each sentence
        for sentence in sentences:
            sentence = sentence.strip()
            if any(keyword in sentence.lower() for keyword in self.conclusion_keywords):
                return sentence
                
        # If no explicit conclusion found, use last sentence as default if different from claim
        if len(sentences) > 1 and sentences[-1].strip() != self._extract_claim(text):
            return sentences[-1].strip()
            
        return ""
    
    def _extract_key_terms(self, text: str) -> List[str]:
        """Extract key terms from the argument."""
        # Remove common stop words
        stop_words = {"a", "an", "the", "and", "or", "but", "is", "are", "was", "were", 
                       "be", "been", "being", "in", "on", "at", "to", "for", "with", 
                       "by", "about", "against", "between", "through", "during", "before",
                       "after", "above", "below", "from", "up", "down", "of", "this", "that"}
        
        # Split text into words and filter out stop words
        words = [word.lower() for word in re.findall(r'\b[a-zA-Z]{4,}\b', text)]
        filtered_words = [word for word in words if word not in stop_words]
        
        # Count word frequencies
        word_counts = {}
        for word in filtered_words:
            if word in word_counts:
                word_counts[word] += 1
            else:
                word_counts[word] = 1
        
        # Sort by frequency and return top terms
        sorted_terms = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
        return [term for term, count in sorted_terms[:5]]
    
    def _generate_reasoning_steps(self, claim: str, evidence: List[str], conclusion: str) -> List[str]:
        """Generate chain-of-thought reasoning steps."""
        steps = []
        
        # Level 1: Basic reasoning 
        steps.append(f"Identified claim: {claim}")
        
        for i, ev in enumerate(evidence):
            steps.append(f"Evidence {i+1}: {ev}")
        
        if conclusion:
            steps.append(f"Conclusion: {conclusion}")
        
        # Add more complex reasoning based on complexity level
        if self.complexity_level >= 2:
            evidence_analysis = self._analyze_evidence_quality(evidence)
            steps.append(evidence_analysis)
            
            if claim and (evidence or conclusion):
                logical_step = self._analyze_logical_flow(claim, evidence, conclusion)
                steps.append(logical_step)
        
        if self.complexity_level >= 3:
            if evidence:
                evidence_relevance = self._analyze_evidence_relevance(claim, evidence, conclusion)
                steps.append(evidence_relevance)
                
            counter_analysis = self._consider_counterarguments(claim, evidence, conclusion)
            steps.append(counter_analysis)
            
        # Add concluding evaluation step
        if self.complexity_level == 1:
            if evidence and conclusion:
                steps.append("Basic evaluation: The argument has a claim with supporting evidence and conclusion.")
            elif evidence:
                steps.append("Basic evaluation: The argument has a claim with supporting evidence but lacks a clear conclusion.")
            elif conclusion:
                steps.append("Basic evaluation: The argument has a claim and conclusion but lacks supporting evidence.")
            else:
                steps.append("Basic evaluation: The argument consists of a claim without evidence or conclusion.")
        else:
            # More nuanced conclusion at higher complexity levels
            strengths = []
            weaknesses = []
            
            if claim:
                strengths.append("clearly stated claim")
            else:
                weaknesses.append("unclear main claim")
                
            if len(evidence) >= 2:
                strengths.append("multiple pieces of supporting evidence")
            elif len(evidence) == 1:
                strengths.append("some supporting evidence")
            else:
                weaknesses.append("lack of supporting evidence")
                
            if conclusion:
                strengths.append("logical conclusion")
            else:
                weaknesses.append("missing conclusion")
                
            strength_text = ", ".join(strengths)
            weakness_text = ", ".join(weaknesses)
            
            if strengths and weaknesses:
                steps.append(f"Overall evaluation: The argument has strengths ({strength_text}) and weaknesses ({weakness_text}).")
            elif strengths:
                steps.append(f"Overall evaluation: The argument has notable strengths ({strength_text}).")
            else:
                steps.append(f"Overall evaluation: The argument has significant weaknesses ({weakness_text}).")
            
        return steps
    
    def _analyze_evidence_quality(self, evidence: List[str]) -> str:
        """Analyze the quality of provided evidence (complexity level 2)."""
        if not evidence:
            return "Evidence analysis: No evidence provided to analyze."
        
        # Quality indicators
        quality_terms = {
            "statistical": ["percent", "study", "survey", "poll", "statistics", "data", "number", "figure"],
            "authoritative": ["expert", "authority", "professor", "doctor", "scientist", "research", "study"],
            "specific": ["specifically", "particular", "detail", "example", "instance", "case"]
        }
        
        evidence_text = " ".join(evidence).lower()
        evidence_strengths = []
        
        for quality_type, terms in quality_terms.items():
            if any(term in evidence_text for term in terms):
                evidence_strengths.append(quality_type)
        
        if not evidence_strengths:
            return "Evidence analysis: Evidence provided is general without specific statistics, examples, or expert sources."
        elif len(evidence_strengths) == 1:
            return f"Evidence analysis: Evidence includes {evidence_strengths[0]} support, which strengthens the argument."
        else:
            strength_text = " and ".join(evidence_strengths)
            return f"Evidence analysis: Evidence combines {strength_text} support, creating a strong foundation for the argument."
    
    def _analyze_logical_flow(self, claim: str, evidence: List[str], conclusion: str) -> str:
        """Analyze the logical flow between claim, evidence, and conclusion (complexity level 2)."""
        if not claim:
            return "Logical flow analysis: Without a clear claim, the logical flow is broken."
            
        # Check connections between components
        if not evidence and not conclusion:
            return "Logical flow analysis: The argument lacks both evidence and conclusion, leaving the claim unsupported."
        elif not evidence:
            return "Logical flow analysis: The argument jumps from claim to conclusion without supporting evidence."
        elif not conclusion:
            return "Logical flow analysis: The argument provides evidence but doesn't explicitly state the logical conclusion."
            
        # Assess if conclusion follows from evidence and relates to claim
        claim_words = set(claim.lower().split())
        evidence_words = set(" ".join(evidence).lower().split())
        conclusion_words = set(conclusion.lower().split())
        
        claim_evidence_overlap = len(claim_words.intersection(evidence_words))
        evidence_conclusion_overlap = len(evidence_words.intersection(conclusion_words))
        claim_conclusion_overlap = len(claim_words.intersection(conclusion_words))
        
        if claim_evidence_overlap > 2 and evidence_conclusion_overlap > 2 and claim_conclusion_overlap > 2:
            return "Logical flow analysis: Strong connections exist between claim, evidence, and conclusion, creating a coherent argument."
        elif claim_evidence_overlap > 2 and evidence_conclusion_overlap > 2:
            return "Logical flow analysis: The evidence connects well to both claim and conclusion, though the relationship could be clearer."
        elif claim_evidence_overlap > 2:
            return "Logical flow analysis: The evidence supports the claim, but the conclusion doesn't clearly follow from the evidence."
        elif evidence_conclusion_overlap > 2:
            return "Logical flow analysis: The conclusion follows from the evidence, but the evidence doesn't clearly relate to the initial claim."
        else:
            return "Logical flow analysis: Weak logical connections between claim, evidence, and conclusion create a disjointed argument."
    
    def _analyze_evidence_relevance(self, claim: str, evidence: List[str], conclusion: str) -> str:
        """Analyze how relevant the evidence is to the claim and conclusion (complexity level 3)."""
        if not evidence:
            return "Evidence relevance: No evidence to evaluate for relevance."
            
        if not claim:
            return "Evidence relevance: Without a clear claim, evidence relevance cannot be determined."
            
        # Extract key terms from claim, evidence, and conclusion
        claim_terms = set(self._extract_key_terms(claim))
        evidence_terms = set(self._extract_key_terms(" ".join(evidence)))
        conclusion_terms = set(self._extract_key_terms(conclusion)) if conclusion else set()
        
        # Calculate overlaps
        claim_evidence_relevance = len(claim_terms.intersection(evidence_terms)) / max(1, len(claim_terms))
        conclusion_evidence_relevance = len(conclusion_terms.intersection(evidence_terms)) / max(1, len(conclusion_terms)) if conclusion_terms else 0
        
        # Assess relevance
        if claim_evidence_relevance > 0.5:
            if conclusion and conclusion_evidence_relevance > 0.5:
                return "Evidence relevance: Evidence is highly relevant to both the claim and conclusion, strengthening the argument's coherence."
            else:
                return "Evidence relevance: Evidence is highly relevant to the claim but less connected to the conclusion."
        elif conclusion and conclusion_evidence_relevance > 0.5:
            return "Evidence relevance: Evidence connects strongly to the conclusion but less directly to the initial claim."
        else:
            return "Evidence relevance: Evidence could be more directly relevant to both claim and conclusion."
    
    def _consider_counterarguments(self, claim: str, evidence: List[str], conclusion: str) -> str:
        """Consider potential counterarguments to the position (complexity level 3)."""
        if not claim:
            return "Counterargument analysis: Without a clear claim, counterarguments cannot be properly considered."
            
        # Generate potential counterarguments based on claim type
        claim_lower = claim.lower()
        
        # Check for claim type indicators
        if any(term in claim_lower for term in ["should", "must", "need to", "ought to"]):
            # Normative claim (policy/prescription)
            counter_approaches = [
                "The costs of implementing this approach likely outweigh the benefits",
                "Alternative solutions might be more effective or efficient",
                "Practical implementation challenges make this unfeasible",
                "Unintended consequences could negate the intended benefits",
                "Ethical considerations preclude this approach"
            ]
            selected_counter = random.choice(counter_approaches)
            return f"Counterargument consideration: A critic might argue that '{selected_counter}', which is not addressed in the original argument."
            
        elif any(term in claim_lower for term in ["is", "are", "exists", "occurs", "happens"]):
            # Descriptive claim (factual)
            counter_approaches = [
                "The evidence presented is insufficient or cherry-picked",
                "The reasoning contains logical fallacies",
                "Alternative interpretations of the same evidence exist",
                "Contradictory evidence has been overlooked",
                "The claim oversimplifies a complex reality"
            ]
            selected_counter = random.choice(counter_approaches)
            return f"Counterargument consideration: A critic might argue that '{selected_counter}', which weakens the argument's persuasiveness."
            
        else:
            # General claim
            counter_approaches = [
                "The argument overlooks important context or nuance",
                "Key assumptions underlying the argument may be flawed",
                "The scope of the claim is either too broad or too narrow",
                "The argument neglects important stakeholder perspectives",
                "The framing of the issue predetermines the conclusion"
            ]
            selected_counter = random.choice(counter_approaches)
            return f"Counterargument consideration: A critic might argue that '{selected_counter}', which is not addressed."
    
    def _evaluate_components(self, claim: str, evidence: List[str], conclusion: str) -> Dict[str, Any]:
        """Evaluate the quality of argument components."""
        evaluation = {}
        
        # Evaluate claim
        if claim:
            claim_specificity = self._assess_specificity(claim)
            evaluation["claim"] = {
                "present": True,
                "specificity": claim_specificity,
                "length": len(claim.split())
            }
        else:
            evaluation["claim"] = {"present": False}
            
        # Evaluate evidence
        if evidence:
            evidence_types = self._categorize_evidence(evidence)
            evidence_strength = self._assess_evidence_strength(evidence)
            evaluation["evidence"] = {
                "present": True,
                "count": len(evidence),
                "types": evidence_types,
                "strength": evidence_strength
            }
        else:
            evaluation["evidence"] = {"present": False}
            
        # Evaluate conclusion
        if conclusion:
            follows_from_evidence = self._conclusion_follows(conclusion, evidence)
            evaluation["conclusion"] = {
                "present": True,
                "follows_from_evidence": follows_from_evidence
            }
        else:
            evaluation["conclusion"] = {"present": False}
            
        return evaluation
    
    def _assess_specificity(self, text: str) -> float:
        """Assess how specific a piece of text is."""
        # Count specific terms vs. general terms
        specific_indicators = ["specifically", "particular", "exact", "precise", "detailed", "concrete"]
        general_indicators = ["generally", "broadly", "typically", "usually", "often", "sometimes"]
        
        text_lower = text.lower()
        
        specific_count = sum(1 for term in specific_indicators if term in text_lower)
        general_count = sum(1 for term in general_indicators if term in text_lower)
        
        # Check for presence of numbers, which indicate specificity
        has_numbers = bool(re.search(r'\d+', text))
        
        # Check for proper nouns (approximated by capitalized words not at start of sentence)
        words = text.split()
        proper_noun_count = sum(1 for i, word in enumerate(words) if i > 0 and word[0].isupper())
        
        # Calculate specificity score
        base_score = 0.5  # Moderate specificity as default
        score_adjustments = 0
        
        score_adjustments += 0.1 * specific_count
        score_adjustments -= 0.1 * general_count
        score_adjustments += 0.2 if has_numbers else 0
        score_adjustments += 0.05 * min(proper_noun_count, 3)  # Cap at 3 to avoid overweighting
        
        specificity = base_score + score_adjustments
        return max(0.1, min(1.0, specificity))  # Ensure score is between 0.1 and 1.0
    
    def _categorize_evidence(self, evidence: List[str]) -> Dict[str, bool]:
        """Categorize the types of evidence present."""
        evidence_text = " ".join(evidence).lower()
        
        return {
            "statistical": any(term in evidence_text for term in ["percent", "percentage", "number", "rate", "statistics", "data", "survey", "study"]),
            "anecdotal": any(term in evidence_text for term in ["example", "instance", "case", "story", "experience"]),
            "expert": any(term in evidence_text for term in ["expert", "authority", "professor", "researcher", "scientist", "professional", "specialist"]),
            "historical": any(term in evidence_text for term in ["history", "historical", "past", "previously", "tradition", "traditionally"]),
            "analogical": any(term in evidence_text for term in ["like", "similar", "comparison", "analogy", "comparable to", "resembles"])
        }
    
    def _assess_evidence_strength(self, evidence: List[str]) -> float:
        """Assess the overall strength of the evidence."""
        if not evidence:
            return 0.0
            
        # Criteria that strengthen evidence
        evidence_text = " ".join(evidence).lower()
        
        strength_factors = [
            # Diversity of evidence types
            0.2 * min(1.0, sum(1 for _, present in self._categorize_evidence(evidence).items() if present) / 3),
            
            # Quantity of evidence
            0.1 * min(1.0, len(evidence) / 3),
            
            # Statistical evidence
            0.2 if any(term in evidence_text for term in ["study", "research", "data", "statistics", "percent", "survey"]) else 0,
            
            # Specific details
            0.2 if any(term in evidence_text for term in ["specifically", "particular", "detail", "exact"]) or re.search(r'\d+', evidence_text) else 0,
            
            # Attribution to credible sources
            0.2 if any(term in evidence_text for term in ["according to", "researcher", "expert", "study", "journal", "published"]) else 0,
            
            # Recent/timely evidence
            0.1 if any(term in evidence_text for term in ["recent", "latest", "current", "new", "modern", "today"]) else 0
        ]
        
        # Sum up strength factors
        return sum(strength_factors)
    
    def _conclusion_follows(self, conclusion: str, evidence: List[str]) -> float:
        """Assess whether the conclusion logically follows from the evidence."""
        if not evidence:
            return 0.0
            
        evidence_text = " ".join(evidence).lower()
        conclusion_lower = conclusion.lower()
        
        # Check for logical connectors
        has_logical_connectors = any(term in conclusion_lower for term in ["therefore", "thus", "hence", "consequently", "so", "as a result"])
        
        # Check for term overlap between evidence and conclusion
        evidence_words = set(re.findall(r'\b[a-zA-Z]{4,}\b', evidence_text))
        conclusion_words = set(re.findall(r'\b[a-zA-Z]{4,}\b', conclusion_lower))
        word_overlap = len(evidence_words.intersection(conclusion_words)) / max(1, len(conclusion_words))
        
        # Calculate score
        score = 0.3  # Base score
        score += 0.3 if has_logical_connectors else 0
        score += 0.4 * word_overlap
        
        return score
    
    def _identify_logical_connections(self, claim: str, evidence: List[str], conclusion: str) -> Dict[str, float]:
        """Identify logical connections between argument components."""
        connections = {}
        
        if not claim:
            return {"overall_coherence": 0.0}
            
        claim_words = set(claim.lower().split())
        
        # Claim-evidence connection
        if evidence:
            evidence_text = " ".join(evidence).lower()
            evidence_words = set(evidence_text.split())
            
            # Calculate word overlap between claim and evidence
            claim_evidence_overlap = len(claim_words.intersection(evidence_words)) / max(1, len(claim_words))
            
            # Check if evidence directly supports the claim
            supports_claim = any(term in evidence_text for term in ["support", "confirm", "verify", "validate", "demonstrate", "show", "prove"])
            
            # Calculate connection strength
            claim_evidence_connection = 0.3 + (0.5 * claim_evidence_overlap) + (0.2 if supports_claim else 0)
            connections["claim_evidence"] = min(1.0, claim_evidence_connection)
        else:
            connections["claim_evidence"] = 0.0
            
        # Evidence-conclusion connection
        if evidence and conclusion:
            evidence_text = " ".join(evidence).lower()
            evidence_words = set(evidence_text.split())
            conclusion_words = set(conclusion.lower().split())
            
            # Calculate word overlap
            evidence_conclusion_overlap = len(evidence_words.intersection(conclusion_words)) / max(1, len(conclusion_words))
            
            # Check for logical flow indicators
            conclusion_flow = any(term in conclusion.lower() for term in ["therefore", "thus", "hence", "consequently", "it follows", "as a result"])
            
            # Calculate connection strength
            evidence_conclusion_connection = 0.3 + (0.4 * evidence_conclusion_overlap) + (0.3 if conclusion_flow else 0)
            connections["evidence_conclusion"] = min(1.0, evidence_conclusion_connection)
        else:
            connections["evidence_conclusion"] = 0.0
            
        # Claim-conclusion connection
        if claim and conclusion:
            conclusion_words = set(conclusion.lower().split())
            
            # Calculate word overlap
            claim_conclusion_overlap = len(claim_words.intersection(conclusion_words)) / max(1, (len(claim_words) + len(conclusion_words)) / 2)
            
            # Check if conclusion addresses the claim
            addresses_claim = claim_conclusion_overlap > 0.3
            
            # Calculate connection strength
            claim_conclusion_connection = 0.3 + (0.5 * claim_conclusion_overlap) + (0.2 if addresses_claim else 0)
            connections["claim_conclusion"] = min(1.0, claim_conclusion_connection)
        else:
            connections["claim_conclusion"] = 0.0
            
        # Overall coherence
        if connections:
            coherence_score = sum(connections.values()) / len(connections)
            connections["overall_coherence"] = coherence_score
            
        return connections
    
    def _evaluate_validity(
        self, 
        reasoning_steps: List[str], 
        component_evaluation: Dict[str, Any],
        logical_connections: Dict[str, float]
    ) -> float:
        """Evaluate overall argument validity based on reasoning steps and other factors."""
        # Start with a base score
        score = 0.5
        
        # Component completeness
        has_claim = component_evaluation.get("claim", {}).get("present", False)
        has_evidence = component_evaluation.get("evidence", {}).get("present", False)
        has_conclusion = component_evaluation.get("conclusion", {}).get("present", False)
        
        if has_claim and has_evidence and has_conclusion:
            score += 0.15  # Complete argument
        elif has_claim and has_evidence:
            score += 0.1   # Missing conclusion
        elif has_claim and has_conclusion:
            score += 0.05  # Missing evidence
        
        # Evidence quality
        if has_evidence:
            evidence_strength = component_evaluation["evidence"].get("strength", 0)
            score += 0.2 * evidence_strength
            
            # Diversity of evidence types
            evidence_types = component_evaluation["evidence"].get("types", {})
            diverse_evidence = sum(1 for _, present in evidence_types.items() if present)
            score += 0.05 * min(3, diverse_evidence) / 3
        
        # Logical connections
        coherence = logical_connections.get("overall_coherence", 0)
        score += 0.2 * coherence
        
        # Adjust based on specific reasoning steps
        for step in reasoning_steps:
            if "lacks supporting evidence" in step:
                score -= 0.1
            if "lacks a clear claim" in step:
                score -= 0.1
            if "weak logical connections" in step:
                score -= 0.1
            if "strong connections exist" in step:
                score += 0.1
            if "evidence is highly relevant" in step:
                score += 0.1
            
        # Ensure score is between 0 and 1
        return max(0.0, min(1.0, score))
    
    def _generate_suggestions(
        self, 
        validity_score: float, 
        component_evaluation: Dict[str, Any],
        logical_connections: Dict[str, float],
        reasoning_steps: List[str]
    ) -> List[str]:
        """Generate improvement suggestions based on reasoning analysis."""
        suggestions = []
        
        # Claim-related suggestions
        if not component_evaluation.get("claim", {}).get("present", False):
            suggestions.append("Start with a clear, specific claim that states your position")
        elif component_evaluation.get("claim", {}).get("specificity", 1.0) < 0.5:
            suggestions.append("Make your claim more specific and focused")
            
        # Evidence-related suggestions
        if not component_evaluation.get("evidence", {}).get("present", False):
            suggestions.append("Support your claim with relevant evidence (statistics, examples, or expert opinions)")
        elif component_evaluation.get("evidence", {}).get("count", 0) < 2:
            suggestions.append("Add more pieces of evidence to strengthen your argument")
            
        evidence_types = component_evaluation.get("evidence", {}).get("types", {})
        if evidence_types:
            missing_types = []
            
            if not evidence_types.get("statistical", False):
                missing_types.append("statistics")
            if not evidence_types.get("expert", False):
                missing_types.append("expert opinions")
            if not evidence_types.get("anecdotal", False):
                missing_types.append("concrete examples")
                
            if missing_types and len(missing_types) <= 2:
                suggestions.append(f"Consider adding {' and '.join(missing_types)} to diversify your evidence")
                
        # Conclusion-related suggestions
        if not component_evaluation.get("conclusion", {}).get("present", False):
            suggestions.append("End with a clear conclusion that follows from your evidence")
        elif component_evaluation.get("conclusion", {}).get("follows_from_evidence", 1.0) < 0.5:
            suggestions.append("Strengthen the connection between your evidence and conclusion")
            
        # Logical connection suggestions
        if logical_connections.get("claim_evidence", 1.0) < 0.5:
            suggestions.append("Make the connection between your claim and evidence more explicit")
        if logical_connections.get("evidence_conclusion", 1.0) < 0.5:
            suggestions.append("Use transition words like 'therefore' or 'thus' to connect evidence to conclusion")
            
        # Complexity level 3 suggestions
        if self.complexity_level >= 3:
            # Add counterargument suggestions
            if "critic might argue" in " ".join(reasoning_steps):
                suggestions.append("Acknowledge and address potential counterarguments to strengthen your position")
                
            # Add evidence relevance suggestions
            if "could be more directly relevant" in " ".join(reasoning_steps):
                suggestions.append("Choose evidence that more directly supports your specific claim")
                
        # If we already have too many suggestions, prioritize the most important ones
        if len(suggestions) > 5:
            prioritized = []
            
            # Priority order: claim, evidence, conclusion, logical connections
            for suggestion in suggestions:
                if "claim" in suggestion:
                    prioritized.append(suggestion)
                    if len(prioritized) >= 2:
                        break
                        
            for suggestion in suggestions:
                if "evidence" in suggestion and suggestion not in prioritized:
                    prioritized.append(suggestion)
                    if len(prioritized) >= 3:
                        break
                        
            for suggestion in suggestions:
                if "conclusion" in suggestion and suggestion not in prioritized:
                    prioritized.append(suggestion)
                    if len(prioritized) >= 4:
                        break