"""
Prompt Library for AI Debate Coach
Contains templates and scenario configurations for different debate scenarios.
"""
from typing import Dict, List, Any, Optional
import random
import json
import os
import logging

class PromptLibrary:
    """Provides prompt templates and debate scenarios."""
    
    def __init__(self, templates_dir: str = "data/templates"):
        """
        Initialize the prompt library.
        
        Args:
            templates_dir: Directory containing template files
        """
        self.templates_dir = templates_dir
        
        # Create templates directory if it doesn't exist
        os.makedirs(templates_dir, exist_ok=True)
        
        # Load default templates
        self.debate_topics = self._load_default_topics()
        self.argument_templates = self._load_default_argument_templates()
        self.counterargument_templates = self._load_default_counterargument_templates()
        self.feedback_templates = self._load_default_feedback_templates()
        
        # Try to load user-defined templates if they exist
        self._load_custom_templates()
    
    def get_debate_topic(self, category: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a random debate topic, optionally from a specific category.
        
        Args:
            category: Optional category to choose from
            
        Returns:
            Topic dictionary with title, description, and pro/con points
        """
        if category:
            # Filter topics by category
            filtered_topics = [
                topic for topic in self.debate_topics
                if category.lower() in [cat.lower() for cat in topic.get("categories", [])]
            ]
            if filtered_topics:
                return random.choice(filtered_topics)
        
        # If no category specified or no topics in that category, return random topic
        return random.choice(self.debate_topics)
    
    def get_argument_template(self, stance: str = "pro", complexity: int = 2) -> str:
        """
        Get an argument template for a specific stance and complexity.
        
        Args:
            stance: "pro", "con", or "neutral"
            complexity: 1 (simple), 2 (moderate), or 3 (complex)
            
        Returns:
            Template string with placeholders for customization
        """
        complexity = min(max(complexity, 1), 3)  # Ensure valid range
        
        # Find templates matching criteria
        matching_templates = [
            t["template"] for t in self.argument_templates
            if t["stance"].lower() == stance.lower() and t["complexity"] == complexity
        ]
        
        if matching_templates:
            return random.choice(matching_templates)
        else:
            # Fallback to any template with matching stance
            fallback_templates = [
                t["template"] for t in self.argument_templates
                if t["stance"].lower() == stance.lower()
            ]
            
            if fallback_templates:
                return random.choice(fallback_templates)
            else:
                # Final fallback - just return a simple template
                return "I believe that {topic} because {reason}. {evidence} supports this position."
    
    def get_counterargument_template(self, strategy: str, attack_type: str = "general") -> str:
        """
        Get a counterargument template for a specific strategy.
        
        Args:
            strategy: The strategy type (e.g., "challenge_evidence")
            attack_type: The type of attack (e.g., "evidential", "causal")
            
        Returns:
            Template string with placeholders for customization
        """
        # Find templates matching criteria
        matching_templates = [
            t["template"] for t in self.counterargument_templates
            if t["strategy"].lower() == strategy.lower() and t["attack_type"].lower() == attack_type.lower()
        ]
        
        if matching_templates:
            return random.choice(matching_templates)
        else:
            # Fallback to any template with matching strategy
            fallback_templates = [
                t["template"] for t in self.counterargument_templates
                if t["strategy"].lower() == strategy.lower()
            ]
            
            if fallback_templates:
                return random.choice(fallback_templates)
            else:
                # Final fallback - just return a simple template
                return "However, the argument that {claim} is flawed because {reason}."
    
    def get_feedback_template(self, metric: str, score: float) -> str:
        """
        Get a feedback template based on a metric and score.
        
        Args:
            metric: The metric type (e.g., "evidence", "fluency")
            score: The score value (0 to 1)
            
        Returns:
            Feedback string customized to the score
        """
        # Determine score category
        category = "high" if score >= 0.7 else ("medium" if score >= 0.4 else "low")
        
        # Find templates matching criteria
        matching_templates = [
            t["template"] for t in self.feedback_templates
            if t["metric"].lower() == metric.lower() and t["category"].lower() == category.lower()
        ]
        
        if matching_templates:
            return random.choice(matching_templates)
        else:
            # Fallback to any template with matching metric
            fallback_templates = [
                t["template"] for t in self.feedback_templates
                if t["metric"].lower() == metric.lower()
            ]
            
            if fallback_templates:
                return random.choice(fallback_templates)
            else:
                # Final fallback based on category
                if category == "high":
                    return f"Your {metric} is excellent at {score:.0%}. Keep up the good work!"
                elif category == "medium":
                    return f"Your {metric} is adequate at {score:.0%}, but could be improved."
                else:
                    return f"Your {metric} needs significant improvement from its current {score:.0%}."
    
    def get_all_topic_categories(self) -> List[str]:
        """
        Get a list of all available topic categories.
        
        Returns:
            List of category strings
        """
        categories = set()
        for topic in self.debate_topics:
            for category in topic.get("categories", []):
                categories.add(category)
        return sorted(list(categories))
    
    def get_topic_by_title(self, title: str) -> Optional[Dict[str, Any]]:
        """
        Find a topic by its title.
        
        Args:
            title: The topic title to search for
            
        Returns:
            Topic dictionary or None if not found
        """
        for topic in self.debate_topics:
            if topic["title"].lower() == title.lower():
                return topic
        return None
    
    def add_custom_topic(self, topic_data: Dict[str, Any]) -> bool:
        """
        Add a custom debate topic.
        
        Args:
            topic_data: Dictionary containing topic details
            
        Returns:
            True if added successfully, False otherwise
        """
        # Validate required fields
        required_fields = ["title", "description", "pro_points", "con_points"]
        for field in required_fields:
            if field not in topic_data:
                return False
                
        # Add categories if not present
        if "categories" not in topic_data:
            topic_data["categories"] = ["General"]
            
        # Add to topics list
        self.debate_topics.append(topic_data)
        
        # Save to custom file
        return self._save_custom_topics()
    
    def add_custom_template(self, template_type: str, template_data: Dict[str, Any]) -> bool:
        """
        Add a custom template.
        
        Args:
            template_type: Type of template ("argument", "counterargument", or "feedback")
            template_data: Dictionary containing template details
            
        Returns:
            True if added successfully, False otherwise
        """
        # Validate template type
        if template_type not in ["argument", "counterargument", "feedback"]:
            return False
            
        # Validate required fields
        if template_type == "argument":
            required_fields = ["template", "stance", "complexity"]
        elif template_type == "counterargument":
            required_fields = ["template", "strategy", "attack_type"]
        elif template_type == "feedback":
            required_fields = ["template", "metric", "category"]
            
        for field in required_fields:
            if field not in template_data:
                return False
                
        # Add to appropriate template list
        if template_type == "argument":
            self.argument_templates.append(template_data)
        elif template_type == "counterargument":
            self.counterargument_templates.append(template_data)
        elif template_type == "feedback":
            self.feedback_templates.append(template_data)
            
        # Save to custom file
        return self._save_custom_templates(template_type)
    
    def _load_default_topics(self) -> List[Dict[str, Any]]:
        """Load default debate topics."""
        return [
            {
                "title": "Should renewable energy be subsidized by governments?",
                "description": "Debate about whether governments should provide financial incentives for renewable energy development.",
                "categories": ["Environment", "Economics", "Politics"],
                "pro_points": [
                    "Accelerates transition to clean energy",
                    "Creates green jobs",
                    "Reduces dependence on foreign oil",
                    "Addresses climate change"
                ],
                "con_points": [
                    "Market distortion",
                    "Tax burden on citizens",
                    "Picks winners and losers",
                    "May benefit wealthy more than poor"
                ]
            },
            {
                "title": "Should college education be free?",
                "description": "Debate about whether higher education should be provided at no cost to students.",
                "categories": ["Education", "Economics", "Social Policy"],
                "pro_points": [
                    "Increases access to education",
                    "Reduces student debt burden",
                    "Creates more skilled workforce",
                    "Promotes social mobility"
                ],
                "con_points": [
                    "High cost to taxpayers",
                    "May reduce educational quality",
                    "Could devalue degrees",
                    "Benefits may not reach those most in need"
                ]
            },
            {
                "title": "Is artificial intelligence a threat to humanity?",
                "description": "Debate about whether AI development poses existential risks to human society.",
                "categories": ["Technology", "Ethics", "Future"],
                "pro_points": [
                    "Could surpass human intelligence and control",
                    "May eliminate jobs at massive scale",
                    "Could be weaponized",
                    "Value alignment is extremely difficult"
                ],
                "con_points": [
                    "Fears are mostly speculative",
                    "AI remains narrow and task-specific",
                    "Benefits outweigh risks",
                    "Proper regulation can mitigate dangers"
                ]
            },
            {
                "title": "Should social media platforms be regulated like utilities?",
                "description": "Debate about whether social media companies should be subject to utility-style regulations.",
                "categories": ["Technology", "Politics", "Media"],
                "pro_points": [
                    "Platforms have monopolistic power",
                    "They serve essential communication functions",
                    "Would ensure equal access and prevent censorship",
                    "Could reduce harmful content"
                ],
                "con_points": [
                    "Would stifle innovation",
                    "Government regulation of speech is problematic",
                    "Platforms should set own standards",
                    "Users have alternatives"
                ]
            }
        ]
    
    def _load_default_argument_templates(self) -> List[Dict[str, Any]]:
        """Load default argument templates."""
        return [
            {
                "template": "I believe that {topic} because {reason}. This is supported by {evidence}.",
                "stance": "pro",
                "complexity": 1
            },
            {
                "template": "I oppose the idea that {topic} for several reasons. First, {reason1}. Furthermore, {reason2}. The evidence clearly shows that {evidence}.",
                "stance": "con",
                "complexity": 2
            },
            {
                "template": "When considering {topic}, we must acknowledge both sides of the debate. On one hand, {pro_point}. However, {con_point}. After weighing the evidence, including {evidence}, I conclude that {conclusion}.",
                "stance": "neutral",
                "complexity": 3
            },
            {
                "template": "There are compelling reasons to support {topic}. The most important is that {reason}. Research has demonstrated {evidence}, which clearly establishes that {conclusion}.",
                "stance": "pro",
                "complexity": 2
            },
            {
                "template": "The proposition that {topic} fails to consider several critical factors. Primarily, {reason1}. Additionally, {reason2}. Moreover, studies have shown that {evidence}. These points clearly demonstrate that {conclusion}.",
                "stance": "con",
                "complexity": 3
            }
        ]
    
    def _load_default_counterargument_templates(self) -> List[Dict[str, Any]]:
        """Load default counterargument templates."""
        return [
            {
                "template": "You claim that {claim}, but the evidence you've presented is insufficient because {reason}.",
                "strategy": "challenge_evidence",
                "attack_type": "evidential"
            },
            {
                "template": "While you argue that {effect} is caused by {claimed_cause}, a more plausible explanation is {alternative}.",
                "strategy": "alternative_cause",
                "attack_type": "causal"
            },
            {
                "template": "Implementing {proposal} as you suggest would lead to the unintended consequence of {consequence}, which is why this approach is problematic.",
                "strategy": "unintended_consequences",
                "attack_type": "consequential"
            },
            {
                "template": "You present a false choice between {option1} and {option2}, when in fact there's another viable alternative: {alternative}.",
                "strategy": "false_dichotomy",
                "attack_type": "logical"
            },
            {
                "template": "Your argument relies on a definition of {term} that is problematic because {reason}.",
                "strategy": "definition_challenge",
                "attack_type": "conceptual"
            }
        ]
    
    def _load_default_feedback_templates(self) -> List[Dict[str, Any]]:
        """Load default feedback templates."""
        return [
            {
                "template": "Your evidence is excellent. You provide specific facts and data to support your claims.",
                "metric": "evidence",
                "category": "high"
            },
            {
                "template": "Your evidence is adequate, but would be stronger with more specific data or expert sources.",
                "metric": "evidence",
                "category": "medium"
            },
            {
                "template": "Your argument lacks sufficient evidence. Try incorporating specific facts, statistics, or expert opinions.",
                "metric": "evidence",
                "category": "low"
            },
            {
                "template": "Your reasoning is logical and well-structured, with clear connections between premises and conclusions.",
                "metric": "reasoning",
                "category": "high"
            },
            {
                "template": "Your reasoning has some gaps. Try to show more clearly how your evidence supports your conclusion.",
                "metric": "reasoning",
                "category": "medium"
            },
            {
                "template": "Your reasoning contains logical fallacies. Review your argument for inconsistencies and flawed logic.",
                "metric": "reasoning",
                "category": "low"
            },
            {
                "template": "Your speech fluency is excellent. You speak clearly with minimal hesitation or filler words.",
                "metric": "fluency",
                "category": "high"
            },
            {
                "template": "Your speech fluency is adequate but could be improved by reducing filler words like 'um' and 'uh'.",
                "metric": "fluency",
                "category": "medium"
            },
            {
                "template": "Your speech contains many filler words and hesitations that reduce its impact. Practice speaking more deliberately.",
                "metric": "fluency",
                "category": "low"
            }
        ]
    
    def _load_custom_templates(self) -> None:
        """Attempt to load custom templates from files."""
        # Load custom topics
        topics_file = os.path.join(self.templates_dir, "custom_topics.json")
        custom_topics = self._load_json(topics_file)
        if custom_topics:
            self.debate_topics.extend(custom_topics)
                
        # Load custom argument templates
        arg_file = os.path.join(self.templates_dir, "custom_argument_templates.json")
        custom_args = self._load_json(arg_file)
        if custom_args:
            self.argument_templates.extend(custom_args)
                
        # Load custom counterargument templates
        counter_file = os.path.join(self.templates_dir, "custom_counterargument_templates.json")
        custom_counters = self._load_json(counter_file)
        if custom_counters:
            self.counterargument_templates.extend(custom_counters)
                
        # Load custom feedback templates
        feedback_file = os.path.join(self.templates_dir, "custom_feedback_templates.json")
        custom_feedback = self._load_json(feedback_file)
        if custom_feedback:
            self.feedback_templates.extend(custom_feedback)
    
    def _load_json(self, file_path: str) -> Optional[List[Dict[str, Any]]]:
        """Helper to load JSON data from a file."""
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
            except (json.JSONDecodeError, IOError) as e:
                logging.error(f"Error loading JSON from {file_path}: {e}")
        return None
    
    def _save_custom_topics(self) -> bool:
        """Save custom topics to file."""
        topics_file = os.path.join(self.templates_dir, "custom_topics.json")
        return self._save_json(topics_file, self.debate_topics)
    
    def _save_custom_templates(self, template_type: str) -> bool:
        """Save custom templates to file."""
        if template_type == "argument":
            template_file = os.path.join(self.templates_dir, "custom_argument_templates.json")
            templates = self.argument_templates
        elif template_type == "counterargument":
            template_file = os.path.join(self.templates_dir, "custom_counterargument_templates.json")
            templates = self.counterargument_templates
        elif template_type == "feedback":
            template_file = os.path.join(self.templates_dir, "custom_feedback_templates.json")
            templates = self.feedback_templates
        else:
            return False
        return self._save_json(template_file, templates)
    
    def _save_json(self, file_path: str, data: List[Dict[str, Any]]) -> bool:
        """Helper to save data as JSON to a file."""
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            return True
        except IOError as e:
            logging.error(f"Error saving JSON to {file_path}: {e}")
            return False
