"""
Logging Monitor for AI Debate Coach
Centralized logging for system diagnostics and user session analytics.
"""
import logging
import os
import json
import datetime
import time
from typing import Dict, List, Any, Optional, Union
import traceback

class LoggingMonitor:
    """Centralized logging and monitoring system."""
    
    def __init__(
        self,
        log_dir: str = "logs",
        level: int = logging.INFO,
        enable_console: bool = True
    ):
        """
        Initialize the logging monitor.
        
        Args:
            log_dir: Directory to store log files
            level: Logging level (e.g., logging.INFO)
            enable_console: Whether to output logs to console
        """
        self.log_dir = log_dir
        self.level = level
        self.enable_console = enable_console
        
        # Create log directory if it doesn't exist
        os.makedirs(log_dir, exist_ok=True)
        
        # Set up file paths
        current_date = datetime.datetime.now().strftime("%Y%m%d")
        self.system_log_file = os.path.join(log_dir, f"system_{current_date}.log")
        self.api_log_file = os.path.join(log_dir, f"api_{current_date}.log")
        self.user_activity_log_file = os.path.join(log_dir, f"user_activity_{current_date}.log")
        self.error_log_file = os.path.join(log_dir, f"error_{current_date}.log")
        
        # Set up loggers
        self.system_logger = self._setup_logger("system", self.system_log_file)
        self.api_logger = self._setup_logger("api", self.api_log_file)
        self.user_logger = self._setup_logger("user", self.user_activity_log_file)
        self.error_logger = self._setup_logger("error", self.error_log_file, level=logging.ERROR)
        
        # Initialize counters
        self.request_count = 0
        self.error_count = 0
        self.start_time = time.time()
        
        # Log system startup
        self.system_logger.info("Logging system initialized")
    
    def _setup_logger(
        self,
        name: str,
        log_file: str,
        level: Optional[int] = None
    ) -> logging.Logger:
        """
        Set up a logger with file and optional console handlers.
        
        Args:
            name: Logger name
            log_file: File path for logs
            level: Logging level (defaults to self.level)
            
        Returns:
            Configured logger
        """
        if level is None:
            level = self.level
            
        logger = logging.getLogger(name)
        logger.setLevel(level)
        
        # Clear any existing handlers
        if logger.handlers:
            logger.handlers = []
            
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # File handler
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        # Console handler (optional)
        if self.enable_console:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(level)
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
            
        return logger
    
    def log_system_event(self, message: str, level: str = "info") -> None:
        """
        Log a system event.
        
        Args:
            message: The log message
            level: Log level ("debug", "info", "warning", "error", "critical")
        """
        self._log(self.system_logger, message, level)
    
    def log_api_request(
        self,
        endpoint: str,
        method: str,
        request_data: Optional[Dict[str, Any]] = None,
        response_code: Optional[int] = None,
        response_time_ms: Optional[float] = None,
        error: Optional[str] = None
    ) -> None:
        """
        Log an API request.
        
        Args:
            endpoint: API endpoint
            method: HTTP method
            request_data: Request data (if any)
            response_code: HTTP response code
            response_time_ms: Response time in milliseconds
            error: Error message (if any)
        """
        self.request_count += 1
        
        log_data = {
            "endpoint": endpoint,
            "method": method,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        if request_data:
            # Sanitize sensitive data if needed
            sanitized_data = self._sanitize_data(request_data)
            log_data["request_data"] = sanitized_data
            
        if response_code is not None:
            log_data["response_code"] = response_code
            
        if response_time_ms is not None:
            log_data["response_time_ms"] = response_time_ms
            
        if error:
            log_data["error"] = error
            self.error_count += 1
            level = "error"
        else:
            level = "info"
            
        self._log(self.api_logger, json.dumps(log_data), level)
    
    def log_user_activity(
        self,
        activity_type: str,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log user activity.
        
        Args:
            activity_type: Type of activity
            session_id: Session identifier
            user_id: User identifier
            details: Additional activity details
        """
        log_data = {
            "activity_type": activity_type,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        if session_id:
            log_data["session_id"] = session_id
            
        if user_id:
            log_data["user_id"] = user_id
            
        if details:
            # Sanitize sensitive data if needed
            sanitized_details = self._sanitize_data(details)
            log_data["details"] = sanitized_details
            
        self._log(self.user_logger, json.dumps(log_data), "info")
    
    def log_error(
        self,
        error_message: str,
        exception: Optional[Exception] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log an error with stack trace.
        
        Args:
            error_message: Error message
            exception: Exception object
            context: Contextual information
        """
        self.error_count += 1
        
        log_data = {
            "error_message": error_message,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        if exception:
            log_data["exception_type"] = type(exception).__name__
            log_data["stack_trace"] = traceback.format_exc()
            
        if context:
            # Sanitize sensitive data if needed
            sanitized_context = self._sanitize_data(context)
            log_data["context"] = sanitized_context
            
        self._log(self.error_logger, json.dumps(log_data), "error")
        self._log(self.system_logger, f"ERROR: {error_message}", "error")
    
    def get_system_stats(self) -> Dict[str, Any]:
        """
        Get system statistics.
        
        Returns:
            Dict containing system statistics
        """
        uptime_seconds = time.time() - self.start_time
        uptime_formatted = str(datetime.timedelta(seconds=int(uptime_seconds)))
        
        return {
            "uptime_seconds": uptime_seconds,
            "uptime_formatted": uptime_formatted,
            "request_count": self.request_count,
            "error_count": self.error_count,
            "error_rate": self.error_count / max(1, self.request_count),
            "timestamp": datetime.datetime.now().isoformat()
        }
    
    def rotate_logs(self) -> None:
        """Rotate log files to start fresh ones with current date."""
        # Update file paths with current date
        current_date = datetime.datetime.now().strftime("%Y%m%d")
        self.system_log_file = os.path.join(self.log_dir, f"system_{current_date}.log")
        self.api_log_file = os.path.join(self.log_dir, f"api_{current_date}.log")
        self.user_activity_log_file = os.path.join(self.log_dir, f"user_activity_{current_date}.log")
        self.error_log_file = os.path.join(self.log_dir, f"error_{current_date}.log")
        
        # Re-setup loggers
        self.system_logger = self._setup_logger("system", self.system_log_file)
        self.api_logger = self._setup_logger("api", self.api_log_file)
        self.user_logger = self._setup_logger("user", self.user_activity_log_file)
        self.error_logger = self._setup_logger("error", self.error_log_file, level=logging.ERROR)
        
        self.system_logger.info("Log files rotated")
    
    def _log(self, logger: logging.Logger, message: str, level: str = "info") -> None:
        """
        Log a message at the specified level.
        
        Args:
            logger: Logger to use
            message: Message to log
            level: Log level
        """
        if level == "debug":
            logger.debug(message)
        elif level == "info":
            logger.info(message)
        elif level == "warning":
            logger.warning(message)
        elif level == "error":
            logger.error(message)
        elif level == "critical":
            logger.critical(message)
        else:
            logger.info(message)  # Default to info
    
    def _sanitize_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sanitize potentially sensitive data.
        
        Args:
            data: Data to sanitize
            
        Returns:
            Sanitized data
        """
        # Create a copy to avoid modifying the original
        sanitized = data.copy()
        
        # Define sensitive fields to mask
        sensitive_fields = [
            "password", "api_key", "secret", "token", "auth",
            "credit_card", "ssn", "social_security", "personal"
        ]
        
        # Helper function to recursively sanitize nested dicts
        def sanitize_dict(d: Dict[str, Any]) -> Dict[str, Any]:
            for key, value in d.items():
                # Check if key contains sensitive info
                if any(field in key.lower() for field in sensitive_fields):
                    d[key] = "[REDACTED]"
                    
                # Recursively process nested dicts
                elif isinstance(value, dict):
                    d[key] = sanitize_dict(value)
                    
                # Recursively process lists of dicts
                elif isinstance(value, list):
                    for i, item in enumerate(value):
                        if isinstance(item, dict):
                            value[i] = sanitize_dict(item)
                            
            return d
                
        return sanitize_dict(sanitized)

# Get a global instance for use throughout the application
def get_logger(
    log_dir: str = "logs",
    level: int = logging.INFO,
    enable_console: bool = True
) -> LoggingMonitor:
    """
    Get a global logging monitor instance.
    
    Args:
        log_dir: Directory to store log files
        level: Logging level
        enable_console: Whether to output logs to console
        
    Returns:
        LoggingMonitor instance
    """
    if not hasattr(get_logger, "instance"):
        get_logger.instance = LoggingMonitor(log_dir, level, enable_console)
        
    return get_logger.instance