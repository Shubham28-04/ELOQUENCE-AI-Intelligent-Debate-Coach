"""
Data Ingestion for AI Debate Coach
Handles real-time data streams from speech and reasoning engines.
"""
import json
import os
import datetime
import csv
from typing import Dict, List, Any, Optional, Union
from pathlib import Path

class DataIngestion:
    """Handles ingestion and storage of data from various sources."""
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize the data ingestion module.
        
        Args:
            data_dir: Directory to store ingested data
        """
        self.data_dir = data_dir
        self.session_dir = os.path.join(data_dir, "sessions")
        self.argument_dir = os.path.join(data_dir, "arguments")
        self.transcript_dir = os.path.join(data_dir, "transcripts")
        
        # Create necessary directories
        for directory in [self.data_dir, self.session_dir, self.argument_dir, self.transcript_dir]:
            os.makedirs(directory, exist_ok=True)
    
    def save_session(
        self, 
        session_id: str, 
        session_data: Dict[str, Any]
    ) -> str:
        """
        Save a complete session.
        
        Args:
            session_id: Unique identifier for the session
            session_data: Dictionary containing session data
            
        Returns:
            Path to the saved session file
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{session_id}_{timestamp}.json"
        filepath = os.path.join(self.session_dir, filename)
        
        # Add metadata
        session_data["meta"] = {
            "session_id": session_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "version": "0.1.0"
        }
        
        with open(filepath, 'w') as f:
            json.dump(session_data, f, indent=2)
            
        return filepath
    
    def save_argument(
        self, 
        argument_text: str, 
        analysis_results: Dict[str, Any], 
        session_id: Optional[str] = None
    ) -> str:
        """
        Save an analyzed argument.
        
        Args:
            argument_text: The original argument text
            analysis_results: Results of argument analysis
            session_id: Optional session ID to associate with this argument
            
        Returns:
            Path to the saved argument file
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        argument_id = f"arg_{timestamp}"
        filename = f"{argument_id}.json"
        filepath = os.path.join(self.argument_dir, filename)
        
        # Prepare data structure
        data = {
            "argument_id": argument_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "argument_text": argument_text,
            "analysis_results": analysis_results
        }
        
        if session_id:
            data["session_id"] = session_id
            
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
            
        return filepath
    
    def save_transcript(
        self, 
        transcript_text: str, 
        analysis_results: Dict[str, Any], 
        session_id: Optional[str] = None
    ) -> str:
        """
        Save an analyzed speech transcript.
        
        Args:
            transcript_text: The original transcript text
            analysis_results: Results of speech analysis
            session_id: Optional session ID to associate with this transcript
            
        Returns:
            Path to the saved transcript file
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        transcript_id = f"trans_{timestamp}"
        filename = f"{transcript_id}.json"
        filepath = os.path.join(self.transcript_dir, filename)
        
        # Prepare data structure
        data = {
            "transcript_id": transcript_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "transcript_text": transcript_text,
            "analysis_results": analysis_results
        }
        
        if session_id:
            data["session_id"] = session_id
            
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
            
        return filepath
    
    def export_arguments_csv(self, output_path: Optional[str] = None) -> str:
        """
        Export all arguments to a CSV file.
        
        Args:
            output_path: Optional path for the CSV file
            
        Returns:
            Path to the exported CSV file
        """
        if output_path is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(self.data_dir, f"arguments_export_{timestamp}.csv")
            
        arguments = self.list_arguments()
        
        if not arguments:
            return ""
            
        # Determine CSV fields
        fields = ["argument_id", "timestamp", "argument_text", "session_id"]
        
        # Add common analysis fields
        analysis_fields = [
            "validity_score",
            "evidence_count",
            "has_claim",
            "has_evidence",
            "has_conclusion"
        ]
        
        # Write to CSV
        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fields + analysis_fields)
            writer.writeheader()
            
            for arg in arguments:
                row = {
                    "argument_id": arg.get("argument_id", ""),
                    "timestamp": arg.get("timestamp", ""),
                    "argument_text": arg.get("argument_text", ""),
                    "session_id": arg.get("session_id", "")
                }
                
                # Extract analysis fields
                analysis = arg.get("analysis_results", {})
                for field in analysis_fields:
                    row[field] = analysis.get(field, "")
                    
                writer.writerow(row)
                
        return output_path
    
    def export_transcripts_csv(self, output_path: Optional[str] = None) -> str:
        """
        Export all transcripts to a CSV file.
        
        Args:
            output_path: Optional path for the CSV file
            
        Returns:
            Path to the exported CSV file
        """
        if output_path is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(self.data_dir, f"transcripts_export_{timestamp}.csv")
            
        transcripts = self.list_transcripts()
        
        if not transcripts:
            return ""
            
        # Determine CSV fields
        fields = ["transcript_id", "timestamp", "transcript_text", "session_id"]
        
        # Add common analysis fields
        analysis_fields = [
            "fluency_score",
            "filler_count",
            "word_count",
            "filler_density"
        ]
        
        # Write to CSV
        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fields + analysis_fields)
            writer.writeheader()
            
            for trans in transcripts:
                row = {
                    "transcript_id": trans.get("transcript_id", ""),
                    "timestamp": trans.get("timestamp", ""),
                    "transcript_text": trans.get("transcript_text", ""),
                    "session_id": trans.get("session_id", "")
                }
                
                # Extract analysis fields
                analysis = trans.get("analysis_results", {})
                for field in analysis_fields:
                    row[field] = analysis.get(field, "")
                    
                writer.writerow(row)
                
        return output_path
    
    def list_sessions(self) -> List[Dict[str, Any]]:
        """
        List all saved sessions.
        
        Returns:
            List of session data dictionaries
        """
        sessions = []
        for filename in os.listdir(self.session_dir):
            if filename.endswith(".json"):
                try:
                    with open(os.path.join(self.session_dir, filename), 'r') as f:
                        session_data = json.load(f)
                        sessions.append(session_data)
                except (json.JSONDecodeError, IOError):
                    # Skip invalid files
                    continue
                    
        return sessions
    
    def list_arguments(self) -> List[Dict[str, Any]]:
        """
        List all saved arguments.
        
        Returns:
            List of argument data dictionaries
        """
        arguments = []
        for filename in os.listdir(self.argument_dir):
            if filename.endswith(".json"):
                try:
                    with open(os.path.join(self.argument_dir, filename), 'r') as f:
                        arg_data = json.load(f)
                        arguments.append(arg_data)
                except (json.JSONDecodeError, IOError):
                    # Skip invalid files
                    continue
                    
        return arguments
    
    def list_transcripts(self) -> List[Dict[str, Any]]:
        """
        List all saved transcripts.
        
        Returns:
            List of transcript data dictionaries
        """
        transcripts = []
        for filename in os.listdir(self.transcript_dir):
            if filename.endswith(".json"):
                try:
                    with open(os.path.join(self.transcript_dir, filename), 'r') as f:
                        transcript_data = json.load(f)
                        transcripts.append(transcript_data)
                except (json.JSONDecodeError, IOError):
                    # Skip invalid files
                    continue
                    
        return transcripts
    
    def get_session_by_id(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a session by its ID.
        
        Args:
            session_id: The session ID to look for
            
        Returns:
            Session data dictionary or None if not found
        """
        for session in self.list_sessions():
            meta = session.get("meta", {})
            if meta.get("session_id") == session_id:
                return session
                
        return None
    
    def get_arguments_by_session(self, session_id: str) -> List[Dict[str, Any]]:
        """
        Retrieve all arguments associated with a session ID.
        
        Args:
            session_id: The session ID to look for
            
        Returns:
            List of argument data dictionaries
        """
        return [
            arg for arg in self.list_arguments()
            if arg.get("session_id") == session_id
        ]
    
    def get_transcripts_by_session(self, session_id: str) -> List[Dict[str, Any]]:
        """
        Retrieve all transcripts associated with a session ID.
        
        Args:
            session_id: The session ID to look for
            
        Returns:
            List of transcript data dictionaries
        """
        return [
            trans for trans in self.list_transcripts()
            if trans.get("session_id") == session_id
        ]
    
    def clean_old_data(self, days: int = 30) -> int:
        """
        Remove data older than specified number of days.
        
        Args:
            days: Number of days to keep data for
            
        Returns:
            Number of files removed
        """
        cutoff_date = datetime.datetime.now() - datetime.timedelta(days=days)
        removed_count = 0
        
        for directory in [self.session_dir, self.argument_dir, self.transcript_dir]:
            for filename in os.listdir(directory):
                if not filename.endswith(".json"):
                    continue
                    
                filepath = os.path.join(directory, filename)
                file_time = datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
                
                if file_time < cutoff_date:
                    try:
                        os.remove(filepath)
                        removed_count += 1
                    except OSError:
                        # Skip files that can't be removed
                        continue
                        
        return removed_count