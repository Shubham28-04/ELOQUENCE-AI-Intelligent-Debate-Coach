"""
Metrics Calculator for AI Debate Coach
Calculates performance metrics and tracks progress over time.
"""
from typing import List, Dict, Any, Tuple, Optional
import json
import os
import datetime
import statistics
from pathlib import Path

class MetricsCalculator:
    """Calculates and tracks debate performance metrics."""
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize the metrics calculator.
        
        Args:
            data_dir: Directory to store metrics data
        """
        self.data_dir = data_dir
        self.metrics_file = os.path.join(data_dir, "performance_metrics.json")
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        # Load existing metrics if available
        self.metrics_history = self._load_metrics()
        
    def calculate_argument_metrics(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate metrics for an analyzed argument.
        
        Args:
            analysis_results: Results from argument analysis
            
        Returns:
            Dict of calculated metrics
        """
        metrics = {}
        
        # Extract basic metrics
        if "validity_score" in analysis_results:
            metrics["argument_validity"] = analysis_results["validity_score"]
            
        # Count evidence pieces if available
        if "evidence" in analysis_results:
            metrics["evidence_count"] = len(analysis_results.get("evidence", []))
            
        # Count reasoning steps if available
        if "reasoning_steps" in analysis_results:
            metrics["reasoning_depth"] = len(analysis_results.get("reasoning_steps", []))
            
        # Logical fallacies (if available from validator)
        if "detected_fallacies" in analysis_results:
            metrics["fallacy_count"] = len(analysis_results.get("detected_fallacies", []))
            
        # Structure metrics (if available)
        if "structure_analysis" in analysis_results:
            structure = analysis_results["structure_analysis"]
            metrics["has_claim"] = 1 if structure.get("has_claim", False) else 0
            metrics["has_evidence"] = 1 if structure.get("has_evidence", False) else 0
            metrics["has_conclusion"] = 1 if structure.get("has_conclusion", False) else 0
            metrics["sentence_count"] = structure.get("sentence_count", 0)
            
        # Calculate overall argument quality (weighted combination of metrics)
        quality_score = 0
        quality_components = 0
        
        if "argument_validity" in metrics:
            quality_score += metrics["argument_validity"] * 0.5
            quality_components += 0.5
            
        if "evidence_count" in metrics:
            # Normalize evidence count (0-5 scale)
            evidence_score = min(1.0, metrics["evidence_count"] / 5)
            quality_score += evidence_score * 0.3
            quality_components += 0.3
            
        if "fallacy_count" in metrics:
            # Inverse relationship - fewer fallacies is better
            fallacy_score = max(0, 1 - (metrics["fallacy_count"] * 0.2))
            quality_score += fallacy_score * 0.2
            quality_components += 0.2
            
        # Normalize by components used
        if quality_components > 0:
            metrics["overall_quality"] = quality_score / quality_components
        else:
            metrics["overall_quality"] = 0
            
        return metrics
    
    def calculate_speech_metrics(self, speech_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate metrics for speech analysis.
        
        Args:
            speech_results: Results from speech analysis
            
        Returns:
            Dict of calculated metrics
        """
        metrics = {}
        
        # Extract basic metrics
        metrics["word_count"] = speech_results.get("word_count", 0)
        metrics["filler_count"] = speech_results.get("filler_count", 0)
        metrics["filler_density"] = speech_results.get("filler_density", 0)
        
        # Get fluency score if available
        if "fluency_score" in speech_results:
            metrics["fluency_score"] = speech_results["fluency_score"]
            
        # Extract pause metrics if available
        if "pause_analysis" in speech_results:
            pause = speech_results["pause_analysis"]
            metrics["pause_count"] = pause.get("explicit_pauses", 0) + pause.get("implicit_pauses", 0)
            metrics["fragment_ratio"] = pause.get("fragment_ratio", 0)
            
        # Calculate speaking rate (words per minute) - estimate based on average reading speed
        # (assuming average speaker reads at 150 words per minute)
        avg_speaking_rate = 150  # words per minute
        estimated_duration_minutes = metrics["word_count"] / avg_speaking_rate
        metrics["estimated_duration_minutes"] = estimated_duration_minutes
        
        # Calculate overall speaking quality (weighted combination of metrics)
        quality_score = 0
        quality_components = 0
        
        if "fluency_score" in metrics:
            quality_score += metrics["fluency_score"] * 0.6
            quality_components += 0.6
            
        if "filler_density" in metrics:
            # Inverse relationship - lower filler density is better
            filler_score = max(0, 1 - (metrics["filler_density"] * 10))  # Penalize more for higher density
            quality_score += filler_score * 0.2
            quality_components += 0.2
            
        if "fragment_ratio" in metrics:
            # Inverse relationship - lower fragment ratio is better
            fragment_score = max(0, 1 - (metrics["fragment_ratio"] * 2))
            quality_score += fragment_score * 0.2
            quality_components += 0.2
            
        # Normalize by components used
        if quality_components > 0:
            metrics["overall_quality"] = quality_score / quality_components
        else:
            metrics["overall_quality"] = 0
            
        return metrics
    
    def calculate_debate_metrics(
        self, 
        argument_metrics: Dict[str, Any], 
        counterpoints: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Calculate overall debate performance metrics.
        
        Args:
            argument_metrics: Metrics from argument analysis
            counterpoints: List of counterpoints generated
            
        Returns:
            Dict of calculated debate metrics
        """
        metrics = {}
        
        # Incorporate argument quality
        if "overall_quality" in argument_metrics:
            metrics["argument_quality"] = argument_metrics["overall_quality"]
            
        # Assess counterpoint handling
        if counterpoints:
            # Count counterpoints
            metrics["counterpoint_count"] = len(counterpoints)
            
            # Measure counterpoint diversity (by strategy)
            strategies = set(cp.get("strategy", "") for cp in counterpoints)
            metrics["strategy_diversity"] = len(strategies) / max(1, len(counterpoints))
            
            # Calculate average counterpoint difficulty
            if any("rebuttal_difficulty" in cp for cp in counterpoints):
                difficulties = [cp.get("rebuttal_difficulty", 0) for cp in counterpoints if "rebuttal_difficulty" in cp]
                metrics["avg_counterpoint_difficulty"] = sum(difficulties) / len(difficulties) if difficulties else 0
                
        # Calculate overall debate readiness score
        readiness_score = 0
        readiness_components = 0
        
        if "argument_quality" in metrics:
            readiness_score += metrics["argument_quality"] * 0.6
            readiness_components += 0.6
            
        if "strategy_diversity" in metrics:
            readiness_score += metrics["strategy_diversity"] * 0.2
            readiness_components += 0.2
            
        if "avg_counterpoint_difficulty" in metrics:
            # Inverse relationship - higher difficulty means lower readiness
            difficulty_score = 1 - metrics["avg_counterpoint_difficulty"]
            readiness_score += difficulty_score * 0.2
            readiness_components += 0.2
            
        # Normalize by components used
        if readiness_components > 0:
            metrics["debate_readiness"] = readiness_score / readiness_components
        else:
            metrics["debate_readiness"] = 0
            
        return metrics
    
    def save_session_metrics(
        self,
        session_id: str,
        metrics_data: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Save metrics from a session to the metrics history.
        
        Args:
            session_id: Unique identifier for the session
            metrics_data: Metrics to save
            metadata: Additional metadata about the session
            
        Returns:
            True if saved successfully, False otherwise
        """
        # Create new session entry
        session_entry = {
            "session_id": session_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "metrics": metrics_data
        }
        
        # Add metadata if provided
        if metadata:
            session_entry["metadata"] = metadata
            
        # Add to history
        self.metrics_history.append(session_entry)
        
        # Save to disk
        return self._save_metrics()
    
    def get_progress_report(self, metric_keys: List[str], n_sessions: int = 5) -> Dict[str, Any]:
        """
        Generate a progress report for specified metrics.
        
        Args:
            metric_keys: List of metric keys to include in report
            n_sessions: Number of most recent sessions to include
            
        Returns:
            Dict containing progress data
        """
        if not self.metrics_history:
            return {"error": "No metrics history available"}
            
        # Sort sessions by timestamp (newest first)
        sorted_sessions = sorted(
            self.metrics_history,
            key=lambda x: x.get("timestamp", ""),
            reverse=True
        )
        
        # Get the n most recent sessions
        recent_sessions = sorted_sessions[:n_sessions]
        
        # Extract trends for each requested metric
        trends = {}
        for key in metric_keys:
            values = []
            for session in recent_sessions:
                # Navigate nested dicts using dot notation
                if "." in key:
                    parts = key.split(".")
                    value = session
                    for part in parts:
                        if part in value:
                            value = value[part]
                        else:
                            value = None
                            break
                else:
                    value = session.get("metrics", {}).get(key, None)
                
                if value is not None:
                    values.append(value)
            
            if values:
                trends[key] = {
                    "values": values,
                    "latest": values[0],
                    "average": sum(values) / len(values),
                    "trend": self._calculate_trend(values)
                }
                
                # Add improvement percentage if there are at least 2 values
                if len(values) >= 2:
                    improvement = ((values[0] - values[-1]) / max(0.001, abs(values[-1]))) * 100
                    trends[key]["improvement"] = improvement
                    
        return {
            "metric_trends": trends,
            "sessions_analyzed": len(recent_sessions),
            "date_range": {
                "start": recent_sessions[-1].get("timestamp", "") if recent_sessions else "",
                "end": recent_sessions[0].get("timestamp", "") if recent_sessions else ""
            }
        }
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate the trend direction for a series of values."""
        if len(values) < 2:
            return "stable"
            
        # Calculate slope of linear regression
        n = len(values)
        indices = list(range(n))
        
        # Reverse indices so that most recent is last
        indices = [n - 1 - i for i in indices]
        
        if n <= 1:
            return "stable"
            
        # Simple linear regression slope calculation
        mean_x = sum(indices) / n
        mean_y = sum(values) / n
        
        numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(indices, values))
        denominator = sum((x - mean_x) ** 2 for x in indices)
        
        if denominator == 0:
            return "stable"
            
        slope = numerator / denominator
        
        # Determine trend based on slope
        if abs(slope) < 0.05:  # Threshold for "stable"
            return "stable"
        elif slope > 0:
            return "improving"
        else:
            return "declining"
    
    def _load_metrics(self) -> List[Dict[str, Any]]:
        """Load metrics history from file."""
        if not os.path.exists(self.metrics_file):
            return []
            
        try:
            with open(self.metrics_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            # If file is corrupted or can't be read, return empty list
            return []
    
    def _save_metrics(self) -> bool:
        """Save metrics history to file."""
        try:
            with open(self.metrics_file, 'w') as f:
                json.dump(self.metrics_history, f, indent=2)
            return True
        except IOError:
            return False
    
    def get_summary_statistics(self) -> Dict[str, Any]:
        """
        Calculate summary statistics across all sessions.
        
        Returns:
            Dict containing summary statistics
        """
        if not self.metrics_history:
            return {"error": "No metrics history available"}
            
        # Common metrics to analyze
        metric_keys = [
            "overall_quality",
            "argument_quality", 
            "fluency_score",
            "debate_readiness"
        ]
        
        summary = {}
        
        for key in metric_keys:
            values = []
            for session in self.metrics_history:
                if key in session.get("metrics", {}):
                    values.append(session["metrics"][key])
                    
            if values:
                summary[key] = {
                    "mean": statistics.mean(values),
                    "median": statistics.median(values),
                    "min": min(values),
                    "max": max(values)
                }
                
                # Add standard deviation if more than one value
                if len(values) > 1:
                    summary[key]["std_dev"] = statistics.stdev(values)
                    
        # Count total sessions
        summary["total_sessions"] = len(self.metrics_history)
        
        # Calculate improvements
        if len(self.metrics_history) >= 2:
            sorted_sessions = sorted(
                self.metrics_history,
                key=lambda x: x.get("timestamp", "")
            )
            
            first_session = sorted_sessions[0]
            last_session = sorted_sessions[-1]
            
            improvements = {}
            for key in metric_keys:
                first_value = first_session.get("metrics", {}).get(key)
                last_value = last_session.get("metrics", {}).get(key)
                
                if first_value is not None and last_value is not None:
                    change = last_value - first_value
                    percent_change = (change / max(0.001, abs(first_value))) * 100
                    improvements[key] = {
                        "absolute_change": change,
                        "percent_change": percent_change
                    }
                    
            summary["improvements"] = improvements
            
        return summary