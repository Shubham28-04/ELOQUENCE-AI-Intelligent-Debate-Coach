#!/usr/bin/env python
"""
Launcher script for AI Debate Coach
Starts both backend and frontend in separate processes.
"""
import subprocess
import threading
import time
import os
import signal
import sys
import webbrowser
from typing import List
import logging

# Add parent directory to path to import project modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import configuration
try:
    from utils.env_loader import get_config
    config = get_config()
except ImportError:
    # Fallback to default configuration
    print("Warning: Could not load configuration from .env file. Using default values.")
    
    class DefaultConfig:
        def __init__(self):
            self.api_host = "0.0.0.0"
            self.api_port = 8000
            self.api_reload = True
            self.ui_port = 8501
            self.browser_auto_open = True
            self.log_level = "INFO"
            
    config = DefaultConfig()

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.log_level),
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("launcher.log") if hasattr(config, "log_dir") else None
    ]
)
logger = logging.getLogger(__name__)

def print_colored(message: str, color: str):
    """Print a colored message to the terminal."""
    colors = {
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "magenta": "\033[95m",
        "cyan": "\033[96m",
        "end": "\033[0m"
    }
    
    print(f"{colors.get(color, '')}{message}{colors['end']}")

def run_process(cmd: List[str], name: str, color: str):
    """Run a process and capture its output."""
    print_colored(f"Starting {name}...", color)
    logger.info(f"Starting {name} with command: {' '.join(cmd)}")
    
    # Use shell=True on Windows for Python command
    use_shell = sys.platform == "win32" and cmd[0] == "python"
    
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            shell=use_shell
        )
        
        # Store the process for later termination
        global processes
        processes.append(process)
        
        # Print process output with color coding
        while True:
            output = process.stdout.readline()
            if output == "" and process.poll() is not None:
                break
            if output:
                print_colored(f"[{name}] {output.strip()}", color)
                
        return_code = process.poll()
        print_colored(f"{name} exited with return code {return_code}", color)
        logger.info(f"{name} exited with return code {return_code}")
    except Exception as e:
        error_msg = f"Error running {name}: {str(e)}"
        print_colored(error_msg, "red")
        logger.error(error_msg)

def start_api():
    """Start the FastAPI backend."""
    api_cmd = [
        "python", "-m", "uvicorn", 
        "api.fastapi_app:app", 
        "--host", config.api_host, 
        "--port", str(config.api_port)
    ]
    
    # Add reload flag if configured
    if config.api_reload:
        api_cmd.append("--reload")
        
    run_process(api_cmd, "API", "cyan")

def start_ui():
    """Start the Streamlit frontend."""
    ui_cmd = [
        "python", "-m", "streamlit", 
        "run", "frontend/app.py",
        "--server.port", str(config.ui_port)
    ]
    run_process(ui_cmd, "UI", "magenta")

def open_browser():
    """Open web browser to the application."""
    if config.browser_auto_open:
        wait_time = 5  # Seconds to wait for services to start
        print_colored(f"Opening browser in {wait_time} seconds...", "green")
        time.sleep(wait_time)
        webbrowser.open(f"http://localhost:{config.ui_port}")

def check_env_file():
    """Check if .env file exists, create from example if not."""
    if not os.path.exists(".env") and os.path.exists(".env.example"):
        print_colored("No .env file found. Creating from .env.example...", "yellow")
        
        try:
            with open(".env.example", 'r') as example_file:
                with open(".env", 'w') as env_file:
                    env_file.write(example_file.read())
            
            print_colored(".env file created. You may want to review and update the settings.", "green")
        except Exception as e:
            print_colored(f"Error creating .env file: {str(e)}", "red")

def signal_handler(sig, frame):
    """Handle process termination."""
    print_colored("\nShutting down...", "yellow")
    for process in processes:
        try:
            process.terminate()
        except:
            pass
    sys.exit(0)

if __name__ == "__main__":
    # Check for .env file
    check_env_file()
    
    # Store processes for cleanup
    processes = []
    
    # Register signal handler for clean shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create threads for each component
    api_thread = threading.Thread(target=start_api)
    ui_thread = threading.Thread(target=start_ui)
    browser_thread = threading.Thread(target=open_browser)
    
    # Start threads
    api_thread.start()
    
    print_colored("Waiting for API to start...", "yellow")
    time.sleep(5)  # Wait for API to start
    
    ui_thread.start()
    browser_thread.start()
    
    # Display information about the running services
    print_colored(f"""
    ┌─────────────────────────────────┐
    │                                 │
    │       AI Debate Coach           │
    │                                 │
    │   API: http://{config.api_host}:{config.api_port}    │
    │   UI:  http://localhost:{config.ui_port}    │
    │                                 │
    │   Press Ctrl+C to exit          │
    │                                 │
    └─────────────────────────────────┘
    """, "green")
    
    # Wait for threads to finish
    try:
        api_thread.join()
        ui_thread.join()
    except KeyboardInterrupt:
        print_colored("\nExiting...", "yellow")
        for process in processes:
            process.terminate()