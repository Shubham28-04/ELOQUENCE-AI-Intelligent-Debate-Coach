"""
FastAPI application for the AI Debate Coach
Provides API endpoints for core functionalities with enhanced error handling and performance.
"""
from fastapi import FastAPI, HTTPException, Depends, status, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional, Union
import sys
import os
import json
import time
import logging
from datetime import datetime
import uuid

# Add parent directory to path to import project modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import core modules
from core.reasoning_engine.cot_processor import ChainOfThoughtProcessor
from core.reasoning_engine.argument_validator import ArgumentValidator
from core.speech_engine.filler_detector import FillerDetector
from core.debate_engine.counterpoint_engine import CounterpointEngine
from core.debate_engine.socratic_questioner import SocraticQuestioner
from utils.logging_monitor import get_logger
from api.websocket_handler import websocket_handler

# Create FastAPI app
app = FastAPI(
    title="AI Debate Coach API",
    description="API for the AI Debate Coach application",
    version="0.2.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with specific origins in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logger = get_logger()

# Initialize service instances
cot_processor = ChainOfThoughtProcessor(complexity_level=2)
argument_validator = ArgumentValidator()
filler_detector = FillerDetector()
counterpoint_engine = CounterpointEngine(level=2)
socratic_questioner = SocraticQuestioner()

# Pydantic models for request/response
class ArgumentRequest(BaseModel):
    text: str
    complexity_level: Optional[int] = Field(1, ge=1, le=3)

class TranscriptRequest(BaseModel):
    text: str

class CounterpointRequest(BaseModel):
    argument: str
    topic: Optional[str] = ""
    level: Optional[int] = Field(1, ge=1, le=3)

class QuestionRequest(BaseModel):
    argument: str
    count: Optional[int] = Field(3, ge=1, le=5)

class DebateRequest(BaseModel):
    topic: str
    stance: Optional[str] = "neutral"
    arguments: Optional[List[str]] = []

class DebateResponse(BaseModel):
    topic: str
    stance: str
    analysis: Dict[str, Any]
    counterpoints: List[Dict[str, Any]]
    suggestions: List[str]

# Custom exception handler
@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.log_error(f"Unhandled exception: {str(exc)}", exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An unexpected error occurred. Please try again."}
    )

# Performance middleware
@app.middleware("http")
async def add_performance_headers(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    
    # Log API request
    logger.log_api_request(
        endpoint=request.url.path,
        method=request.method,
        response_time_ms=process_time * 1000,
        response_code=response.status_code
    )
    
    return response

# Health check endpoint
@app.get("/health")
async def health_check():
    system_stats = logger.get_system_stats()
    return {
        "status": "healthy", 
        "timestamp": datetime.now().isoformat(),
        "system_stats": system_stats
    }

# Reasoning engine endpoints
@app.post("/reasoning/analyze-argument")
async def analyze_argument(request: ArgumentRequest):
    try:
        # Update complexity level if provided
        if request.complexity_level != 1:
            cot_processor.complexity_level = request.complexity_level
            
        result = cot_processor.process_argument(request.text)
        return result
    except Exception as e:
        logger.log_error(f"Error analyzing argument: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/reasoning/validate-argument")
async def validate_argument(request: ArgumentRequest):
    try:
        result = argument_validator.validate_argument(request.text)
        return result
    except Exception as e:
        logger.log_error(f"Error validating argument: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Speech engine endpoints
@app.post("/speech/analyze-transcript")
async def analyze_transcript(request: TranscriptRequest):
    try:
        result = filler_detector.analyze_transcript(request.text)
        return result
    except Exception as e:
        logger.log_error(f"Error analyzing transcript: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/speech/highlight-fillers")
async def highlight_fillers(request: TranscriptRequest):
    try:
        highlighted = filler_detector.highlight_fillers(request.text)
        return {"original": request.text, "highlighted": highlighted}
    except Exception as e:
        logger.log_error(f"Error highlighting fillers: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Debate engine endpoints
@app.post("/debate/generate-counterpoints")
async def generate_counterpoints(request: CounterpointRequest):
    try:
        # Update complexity level if provided
        if request.level != 1:
            counterpoint_engine.level = min(max(request.level, 1), 3)
            
        result = counterpoint_engine.generate_counterpoints(
            request.argument, 
            request.topic
        )
        return result
    except Exception as e:
        logger.log_error(f"Error generating counterpoints: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/debate/generate-questions")
async def generate_questions(request: QuestionRequest):
    try:
        questions = socratic_questioner.generate_questions(
            request.argument,
            request.count
        )
        
        return {"questions": questions}
    except Exception as e:
        logger.log_error(f"Error generating questions: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/debate/analyze")
async def analyze_debate(request: DebateRequest):
    try:
        # Validate inputs
        if not request.topic:
            raise HTTPException(status_code=400, detail="Topic is required")
            
        # Process arguments if provided
        processed_arguments = []
        for arg in request.arguments:
            processed = cot_processor.process_argument(arg)
            processed_arguments.append(processed)
            
        # Generate counterpoints for the stance
        stance_summary = f"The topic is '{request.topic}' and the stance is '{request.stance}'"
        counterpoints = counterpoint_engine.generate_counterpoints(
            stance_summary,
            request.topic
        )
        
        # Generate socratic questions
        questions = socratic_questioner.generate_questions(stance_summary, 3)
        
        # Generate suggestions
        suggestions = [
            "Focus on developing clear, evidence-based arguments",
            "Anticipate counterpoints to strengthen your position",
            "Structure your debate with a strong opening and conclusion"
        ]
        
        if processed_arguments:
            # Add specific suggestions based on argument analysis
            for i, arg in enumerate(processed_arguments):
                if arg["validity_score"] < 0.7:
                    suggestions.append(f"Strengthen argument #{i+1} with better evidence")
        
        return DebateResponse(
            topic=request.topic,
            stance=request.stance,
            analysis={
                "arguments": processed_arguments,
                "questions": questions
            },
            counterpoints=counterpoints["counterpoints"],
            suggestions=suggestions
        )
    except Exception as e:
        logger.log_error(f"Error analyzing debate: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# WebSocket endpoint for real-time feedback
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await websocket_handler.handle_websocket(websocket, client_id)

@app.websocket("/ws/session/{session_id}/{client_id}")
async def session_websocket_endpoint(websocket: WebSocket, session_id: str, client_id: str):
    await websocket_handler.handle_websocket(websocket, client_id, session_id)

# Run the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)