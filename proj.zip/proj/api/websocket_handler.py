"""
WebSocket Handler for AI Debate Coach
Manages real-time communication and streaming feedback with enhanced reliability.
"""
from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List, Any, Set, Callable, Optional
import json
import asyncio
import logging
import time
import sys
import os



# Add parent directory to path to import project modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import core modules
from utils.logging_monitor import get_logger
from core.reasoning_engine.cot_processor import ChainOfThoughtProcessor
from core.speech_engine.filler_detector import FillerDetector
from core.debate_engine.counterpoint_engine import CounterpointEngine

# Setup logging
logger = get_logger()

class ConnectionManager:
    """Manages WebSocket connections with improved reliability."""
    
    def __init__(self):
        """Initialize the connection manager."""
        self.active_connections: Dict[str, WebSocket] = {}
        self.session_connections: Dict[str, Set[str]] = {}
        self.last_activity: Dict[str, float] = {}
        self.ping_interval = 30  # seconds
    
    async def connect(self, websocket: WebSocket, client_id: str, session_id: str = None) -> None:
        """
        Connect a new WebSocket client with automatic ping-pong.
        
        Args:
            websocket: The WebSocket connection
            client_id: Unique identifier for the client
            session_id: Optional session identifier for group messaging
        """
        await websocket.accept()
        self.active_connections[client_id] = websocket
        self.last_activity[client_id] = time.time()
        
        # Add to session group if provided
        if session_id:
            if session_id not in self.session_connections:
                self.session_connections[session_id] = set()
            self.session_connections[session_id].add(client_id)
            
        logger.log_system_event(f"Client {client_id} connected. Total connections: {len(self.active_connections)}")
        
        # Start ping task
        asyncio.create_task(self._keep_alive(client_id))
    
    def disconnect(self, client_id: str) -> None:
        """
        Disconnect a WebSocket client.
        
        Args:
            client_id: Unique identifier for the client to disconnect
        """
        if client_id in self.active_connections:
            del self.active_connections[client_id]
            if client_id in self.last_activity:
                del self.last_activity[client_id]
            
            # Remove from any session groups
            for session_id, clients in list(self.session_connections.items()):
                if client_id in clients:
                    clients.remove(client_id)
                    
                    # Clean up empty sessions
                    if not clients:
                        del self.session_connections[session_id]
                        
            logger.log_system_event(f"Client {client_id} disconnected. Total connections: {len(self.active_connections)}")
    
    async def _keep_alive(self, client_id: str) -> None:
        """
        Send periodic pings to keep connection alive.
        
        Args:
            client_id: Client to send pings to
        """
        while client_id in self.active_connections:
            try:
                await asyncio.sleep(self.ping_interval)
                if client_id not in self.active_connections:
                    break
                    
                # Send ping message
                await self.send_message(client_id, {"type": "ping", "timestamp": time.time()})
            except Exception:
                # If ping fails, client may be disconnected
                if client_id in self.active_connections:
                    self.disconnect(client_id)
                break
    
    async def send_message(self, client_id: str, message: Any) -> bool:
        """
        Send a message to a specific client with retry mechanism.
        
        Args:
            client_id: Unique identifier for the client
            message: Message to send (will be converted to JSON)
            
        Returns:
            True if sent successfully, False otherwise
        """
        if client_id not in self.active_connections:
            return False
            
        websocket = self.active_connections[client_id]
        
        # Convert message to string if it's not already
        if not isinstance(message, str):
            message = json.dumps(message)
            
        # Try to send with retry
        max_retries = 2
        for attempt in range(max_retries):
            try:
                await websocket.send_text(message)
                self.last_activity[client_id] = time.time()
                return True
            except Exception as e:
                if attempt == max_retries - 1:
                    logger.log_error(f"Error sending message to client {client_id}: {str(e)}")
                    return False
                await asyncio.sleep(0.5)  # Brief delay before retry
    
    async def broadcast(self, message: Any) -> None:
        """
        Broadcast a message to all connected clients.
        
        Args:
            message: Message to broadcast (will be converted to JSON)
        """
        # Convert message to string if it's not already
        if not isinstance(message, str):
            message = json.dumps(message)
            
        disconnected = []
        
        for client_id, websocket in self.active_connections.items():
            try:
                await websocket.send_text(message)
                self.last_activity[client_id] = time.time()
            except Exception as e:
                logger.log_error(f"Error in broadcast to client {client_id}: {str(e)}")
                disconnected.append(client_id)
                
        # Clean up any disconnected clients
        for client_id in disconnected:
            self.disconnect(client_id)
    
    async def broadcast_to_session(self, session_id: str, message: Any) -> None:
        """
        Broadcast a message to all clients in a session.
        
        Args:
            session_id: Session identifier
            message: Message to broadcast (will be converted to JSON)
        """
        if session_id not in self.session_connections:
            return
            
        # Convert message to string if it's not already
        if not isinstance(message, str):
            message = json.dumps(message)
            
        client_ids = list(self.session_connections[session_id])
        disconnected = []
        
        for client_id in client_ids:
            if client_id in self.active_connections:
                try:
                    await self.active_connections[client_id].send_text(message)
                    self.last_activity[client_id] = time.time()
                except Exception as e:
                    logger.log_error(f"Error in session broadcast to client {client_id}: {str(e)}")
                    disconnected.append(client_id)
                    
        # Clean up any disconnected clients
        for client_id in disconnected:
            self.disconnect(client_id)

# Singleton instance
connection_manager = ConnectionManager()

class WebSocketHandler:
    """Handles WebSocket communication and message processing with improved reliability."""
    
    def __init__(self):
        """Initialize the WebSocket handler with core components."""
        self.manager = connection_manager
        self.message_handlers: Dict[str, Callable] = {}
        
        # Initialize core components for immediate response
        self.cot_processor = ChainOfThoughtProcessor(complexity_level=2)
        self.filler_detector = FillerDetector()
        self.counterpoint_engine = CounterpointEngine(level=2)
        
        # Register default handlers
        self._register_default_handlers()
        
    def _register_default_handlers(self):
        """Register default message handlers for common message types."""
        self.register_handler("transcript", self._handle_transcript)
        self.register_handler("argument", self._handle_argument)
        self.register_handler("counterpoint", self._handle_counterpoint)
        self.register_handler("pong", self._handle_pong)
        
    async def _handle_transcript(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle transcript analysis requests."""
        if "text" not in message:
            return {"type": "error", "content": "Missing text field"}
            
        result = self.filler_detector.analyze_transcript(message["text"])
        return {
            "type": "analysis", 
            "analysis_type": "transcript", 
            "data": result,
            "timestamp": time.time()
        }
        
    async def _handle_argument(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle argument analysis requests."""
        if "text" not in message:
            return {"type": "error", "content": "Missing text field"}
            
        # Set complexity if provided
        complexity = message.get("complexity_level", 2)
        self.cot_processor.complexity_level = min(max(complexity, 1), 3)
        
        result = self.cot_processor.process_argument(message["text"])
        return {
            "type": "analysis", 
            "analysis_type": "argument", 
            "data": result,
            "timestamp": time.time()
        }
        
    async def _handle_counterpoint(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle counterpoint generation requests."""
        if "argument" not in message:
            return {"type": "error", "content": "Missing argument field"}
            
        # Set level if provided
        level = message.get("level", 2)
        self.counterpoint_engine.level = min(max(level, 1), 3)
        
        result = self.counterpoint_engine.generate_counterpoints(
            message["argument"],
            message.get("topic", "")
        )
        return {
            "type": "analysis", 
            "analysis_type": "counterpoint", 
            "data": result,
            "timestamp": time.time()
        }
        
    async def _handle_pong(self, message: Dict[str, Any]) -> None:
        """Handle pong responses to keep-alive pings."""
        # Just update the last activity time, no response needed
        client_id = message.get("client_id")
        if client_id in self.manager.last_activity:
            self.manager.last_activity[client_id] = time.time()
        return None
        
    def register_handler(self, message_type: str, handler: Callable) -> None:
        """
        Register a handler for a specific message type.
        
        Args:
            message_type: The type of message to handle
            handler: Callback function to handle the message
        """
        self.message_handlers[message_type] = handler
        logger.log_system_event(f"Registered handler for message type: {message_type}")
        
    async def handle_websocket(self, websocket: WebSocket, client_id: str, session_id: str = None) -> None:
        """
        Handle a WebSocket connection with improved error handling.
        
        Args:
            websocket: The WebSocket connection
            client_id: Unique identifier for the client
            session_id: Optional session identifier for group messaging
        """
        await self.manager.connect(websocket, client_id, session_id)
        
        try:
            # Send welcome message
            await self.manager.send_message(client_id, {
                "type": "system",
                "content": "Connected to AI Debate Coach WebSocket server",
                "client_id": client_id,
                "session_id": session_id,
                "timestamp": time.time()
            })
            
            while True:
                # Receive and process messages
                message_text = await websocket.receive_text()
                await self._process_message(client_id, message_text, session_id)
                
        except WebSocketDisconnect:
            self.manager.disconnect(client_id)
        except Exception as e:
            logger.log_error(f"WebSocket error for client {client_id}: {str(e)}")
            self.manager.disconnect(client_id)
            
    async def _process_message(self, client_id: str, message_text: str, session_id: str = None) -> None:
        """
        Process an incoming WebSocket message with enhanced error handling.
        
        Args:
            client_id: Unique identifier for the client
            message_text: The message text (should be JSON)
            session_id: Optional session identifier
        """
        try:
            # Parse the message
            message = json.loads(message_text)
            
            # Extract message type
            if "type" not in message:
                await self.manager.send_message(client_id, {
                    "type": "error",
                    "content": "Message must include a 'type' field"
                })
                return
                
            message_type = message["type"]
            
            # Update last activity time
            self.manager.last_activity[client_id] = time.time()
            
            # Add metadata to the message
            message["client_id"] = client_id
            if session_id:
                message["session_id"] = session_id
                
            # Handle the message based on type
            if message_type in self.message_handlers:
                # Call the registered handler
                try:
                    result = self.message_handlers[message_type](message)
                    
                    # If the handler returns a coroutine, await it
                    if asyncio.iscoroutine(result):
                        result = await result
                        
                    # If the handler returns a result, send it back to the client
                    if result is not None:
                        await self.manager.send_message(client_id, result)
                except Exception as e:
                    logger.log_error(f"Error in message handler for type {message_type}: {str(e)}")
                    await self.manager.send_message(client_id, {
                        "type": "error",
                        "content": f"Error processing message: {str(e)}"
                    })
            else:
                # Echo back messages with unknown types
                logger.log_system_event(f"No handler for message type: {message_type}", "warning")
                await self.manager.send_message(client_id, {
                    "type": "error",
                    "content": f"Unsupported message type: {message_type}"
                })
                
        except json.JSONDecodeError:
            await self.manager.send_message(client_id, {
                "type": "error",
                "content": "Invalid JSON format"
            })
        except Exception as e:
            logger.log_error(f"Error processing message: {str(e)}")
            await self.manager.send_message(client_id, {
                "type": "error",
                "content": f"Server error: {str(e)}"
            })
            
    async def send_feedback(self, client_id: str, feedback_type: str, content: Any) -> bool:
        """
        Send feedback to a client.
        
        Args:
            client_id: Unique identifier for the client
            feedback_type: Type of feedback
            content: Feedback content
            
        Returns:
            True if sent successfully, False otherwise
        """
        message = {
            "type": "feedback",
            "feedback_type": feedback_type,
            "content": content,
            "timestamp": time.time()
        }
        
        return await self.manager.send_message(client_id, message)
        
    async def send_real_time_analysis(
        self, 
        client_id: str, 
        analysis_type: str, 
        analysis_data: Dict[str, Any]
    ) -> bool:
        """
        Send real-time analysis to a client.
        
        Args:
            client_id: Unique identifier for the client
            analysis_type: Type of analysis
            analysis_data: Analysis data
            
        Returns:
            True if sent successfully, False otherwise
        """
        message = {
            "type": "analysis",
            "analysis_type": analysis_type,
            "data": analysis_data,
            "timestamp": time.time()
        }
        
        return await self.manager.send_message(client_id, message)
        
    async def send_debate_update(
        self, 
        session_id: str, 
        update_type: str, 
        update_data: Dict[str, Any]
    ) -> None:
        """
        Send a debate update to all clients in a session.
        
        Args:
            session_id: Session identifier
            update_type: Type of update
            update_data: Update data
        """
        message = {
            "type": "debate_update",
            "update_type": update_type,
            "data": update_data,
            "timestamp": time.time()
        }
        
        await self.manager.broadcast_to_session(session_id, message)

# Singleton instance
websocket_handler = WebSocketHandler()
